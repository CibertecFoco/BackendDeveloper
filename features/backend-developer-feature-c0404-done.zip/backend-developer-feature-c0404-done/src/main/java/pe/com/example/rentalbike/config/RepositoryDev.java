package pe.com.example.rentalbike.config;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import pe.com.example.api.db.RepositoryManager;
import pe.com.example.rentalbike.thirdparty.Station;
import pe.com.example.rentalbike.thirdparty.dto.BikeQuantity;

@Configuration
@Profile("dev")
@Slf4j
public class RepositoryDev implements RepositoryManager {

  @Override
  public <T> int execute(String query, Map<String, Object> params) throws SQLException {
    // Para la funcionalidad no se utiliza
    return 0;
  }

  @Override
  public <T> List<T> getData(String query, Map<String, Object> params, Class<T> type)
      throws SQLException {
    log.info("[get mock]");
    if (Station.class.getName().equals(type.getName())) {
      log.info("[get stations] {}", getStations());
      return (List<T>) getStations();
    } else if (BikeQuantity.class.getName().equals(type.getName())) {
      log.info("[get bikes] {}", getBikeQuantity());
      return (List<T>) getBikeQuantity();
    }
    return null;
  }

  @Override
  public <T> T getOneData(String query, Map<String, Object> params, Class<T> type) throws SQLException {
    // Para la funcionalidad no se utiliza
    return null;
  }

  private List<Station> getStations() {
    List<Station> lstStations = new LinkedList<>();
    Station station = new Station();
    station.setStationId("S9991");
    station.setName("Name Desa");
    station.setLocation("12345");
    lstStations.add(station);
    return lstStations;
  }

  private List<BikeQuantity> getBikeQuantity() {
    List<BikeQuantity> lstBikeQuantities = new LinkedList<>();
    BikeQuantity bike = new BikeQuantity();
    bike.setBikeId("Bk9991");
    bike.setBrand("RosTer");
    bike.setIsActive(true);
    bike.setPriceByMinute(BigDecimal.ZERO);
    bike.setType("Mono");
    lstBikeQuantities.add(bike);
    return lstBikeQuantities;
  }

}