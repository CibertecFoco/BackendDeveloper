package pe.com.example.rentalbike.business.fn02;

import java.util.List;
import org.springframework.stereotype.Service;
import pe.com.example.rentalbike.models.fn02.response.BikeQuantityResponse;

@Service
public class BikeQuantityServiceImpl implements BikeQuantityService {

  private BikeQuantityProcess process;

  public BikeQuantityServiceImpl(BikeQuantityProcess process) {
    this.process = process;
  }

  @Override
  public List<BikeQuantityResponse> getStationQuantity(String stationId) {
    return process.getBikeAvailable(stationId);
  }
}
