package pe.com.example.api.db;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface RepositoryManager {

  public <T> int execute(String query, Map<String, Object> params) throws SQLException;

  public <T> List<T> getData(String query, Map<String, Object> params, Class<T> type) throws SQLException;

  public <T> T getOneData(String query, Map<String, Object> params, Class<T> type) throws SQLException;

}