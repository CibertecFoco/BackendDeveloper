package pe.com.example.rentalbike.dao;

import java.sql.SQLException;

public interface InsertDao<T> {

  int insert(T t) throws SQLException;

}
