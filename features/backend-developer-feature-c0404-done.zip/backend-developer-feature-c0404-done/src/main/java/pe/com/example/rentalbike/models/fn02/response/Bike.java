package pe.com.example.rentalbike.models.fn02.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Bike implements Serializable {
  private static final long serialVersionUID = 1238166739247716926L;

  @ApiModelProperty(required = true, value = "Code station")
  private String code;

  @ApiModelProperty(required = true, value = "type bike")
  private String type;

  @ApiModelProperty(required = true, value = "brand bike")
  private String brand;

  private AvailableBike available;

  @ApiModelProperty(required = true, value = "Price per minute")
  private BigDecimal priceByMinute;
}
