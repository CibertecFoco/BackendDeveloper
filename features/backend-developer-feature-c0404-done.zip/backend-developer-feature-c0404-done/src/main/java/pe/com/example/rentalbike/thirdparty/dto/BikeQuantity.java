package pe.com.example.rentalbike.thirdparty.dto;

import lombok.Getter;
import lombok.Setter;
import pe.com.example.api.db.DBColumn;
import pe.com.example.rentalbike.thirdparty.Bike;

@Getter
@Setter
public class BikeQuantity extends Bike {

  private static final long serialVersionUID = -5968165841687858920L;

  @DBColumn(columnName = "quantity")
  private int quantity;

}
