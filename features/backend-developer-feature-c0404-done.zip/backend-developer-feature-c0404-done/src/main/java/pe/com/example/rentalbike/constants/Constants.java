package pe.com.example.rentalbike.constants;

public final class Constants {

  public static final String REGEXP_ALPHANUMERIC = "([A-Z1-9]*)";
  public static final String REGEXP_DATE_SHORT_FORMAT = "([1-9]{4}-[1-9]{2}-[1-9]{2})";
  public static final String KEY_HEADER = "header";
  public static final String KEY_PAYLOAD = "payload";

  public static final String KEY_REQUEST_DATE = "request-date";

  public static final String DATE_FULL_ISO = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";

}
