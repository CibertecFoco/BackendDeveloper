package pe.com.example.bikerental.thirdparty;

import java.io.Serializable;
import java.math.BigDecimal;
// import pe.com.example.api.db.DBColumn;


public class Bike implements Serializable {

  private static final long serialVersionUID = 7069630565360912839L;

  // @DBColumn(columnName = "bike_id")
  private String bikeId;

  // @DBColumn(columnName = "type")
  private String type;

  // @DBColumn(columnName = "brand")
  private String brand;

  // @DBColumn(columnName = "is_active")
  private Boolean isActive;

  // @DBColumn(columnName = "price_by_minute")
  private BigDecimal priceByMinute;

  public String getBikeId() {
    return this.bikeId;
  }

  public void setBikeId(String bikeId) {
    this.bikeId = bikeId;
  }

  public String getType() {
    return this.type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getBrand() {
    return this.brand;
  }

  public void setBrand(String brand) {
    this.brand = brand;
  }

  public Boolean isIsActive() {
    return this.isActive;
  }

  public Boolean getIsActive() {
    return this.isActive;
  }

  public void setIsActive(Boolean isActive) {
    this.isActive = isActive;
  }

  public BigDecimal getPriceByMinute() {
    return this.priceByMinute;
  }

  public void setPriceByMinute(BigDecimal priceByMinute) {
    this.priceByMinute = priceByMinute;
  }

}
