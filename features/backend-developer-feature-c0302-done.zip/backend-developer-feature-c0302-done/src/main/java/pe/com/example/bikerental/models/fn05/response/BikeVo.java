package pe.com.example.bikerental.models.fn05.response;

import java.math.BigDecimal;

public class BikeVo {

  private String type;
  private String brand;
  private BigDecimal priceByMinute;

  public String getType() {
    return this.type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getBrand() {
    return this.brand;
  }

  public void setBrand(String brand) {
    this.brand = brand;
  }

  public BigDecimal getPriceByMinute() {
    return this.priceByMinute;
  }

  public void setPriceByMinute(BigDecimal priceByMinute) {
    this.priceByMinute = priceByMinute;
  }

}