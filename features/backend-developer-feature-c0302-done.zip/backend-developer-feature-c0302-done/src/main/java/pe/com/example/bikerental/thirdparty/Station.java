package pe.com.example.bikerental.thirdparty;

import java.io.Serializable;
// import pe.com.example.api.db.DBColumn;

public class Station implements Serializable {

  private static final long serialVersionUID = 7148793598521297654L;

  // @DBColumn(columnName = "station_id")
  private String stationId;

  // @DBColumn(columnName = "name")
  private String name;

  // @DBColumn(columnName = "location")
  private String location;

  // @DBColumn(columnName = "is_active")
  private Boolean isActive;

  public String getStationId() {
    return this.stationId;
  }

  public void setStationId(String stationId) {
    this.stationId = stationId;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getLocation() {
    return this.location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public Boolean isIsActive() {
    return this.isActive;
  }

  public Boolean getIsActive() {
    return this.isActive;
  }

  public void setIsActive(Boolean isActive) {
    this.isActive = isActive;
  }

}
