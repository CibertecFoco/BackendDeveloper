package pe.com.example.bikerental.models.fn05.response;

public class StationVo {

  private StationLocationVo origin;

  public StationLocationVo getOrigin() {
    return this.origin;
  }

  public void setOrigin(StationLocationVo origin) {
    this.origin = origin;
  }

  public StationLocationVo getDestination() {
    return this.destination;
  }

  public void setDestination(StationLocationVo destination) {
    this.destination = destination;
  }

  private StationLocationVo destination;

}