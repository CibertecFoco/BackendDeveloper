package pe.com.example.bikerental.thirdparty;

import java.io.Serializable;
// import pe.com.example.api.db.DBColumn;

public class BookingDetails implements Serializable {

  private static final long serialVersionUID = -2442320298045872942L;

  // @DBColumn(columnName = "station_id")
  private Station stationId;

  // @DBColumn(columnName = "bike_id")
  private Bike bikeId;

  // @DBColumn(columnName = "quantity")
  private Integer quantity;

  // @DBColumn(columnName = "is_active")
  private Boolean isActive;

  public Station getStationId() {
    return this.stationId;
  }

  public void setStationId(Station stationId) {
    this.stationId = stationId;
  }

  public Bike getBikeId() {
    return this.bikeId;
  }

  public void setBikeId(Bike bikeId) {
    this.bikeId = bikeId;
  }

  public Integer getQuantity() {
    return this.quantity;
  }

  public void setQuantity(Integer quantity) {
    this.quantity = quantity;
  }

  public Boolean isIsActive() {
    return this.isActive;
  }

  public Boolean getIsActive() {
    return this.isActive;
  }

  public void setIsActive(Boolean isActive) {
    this.isActive = isActive;
  }

}
