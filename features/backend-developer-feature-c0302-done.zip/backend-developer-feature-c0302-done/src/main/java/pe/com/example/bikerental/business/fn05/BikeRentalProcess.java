package pe.com.example.bikerental.business.fn05;

import java.math.BigDecimal;
import org.springframework.stereotype.Component;
import pe.com.example.bikerental.models.fn05.response.BikeRentalResponse;
import pe.com.example.bikerental.models.fn05.response.BikeVo;
import pe.com.example.bikerental.models.fn05.response.RentalPeriodVo;
import pe.com.example.bikerental.models.fn05.response.StationLocationVo;
import pe.com.example.bikerental.models.fn05.response.StationVo;
import pe.com.example.bikerental.thirdparty.BikeRentalByBooking;

@Component
public class BikeRentalProcess {

  private final BikeRentalRepository repository;

  public BikeRentalProcess(BikeRentalRepository repository) {
    this.repository = repository;
  }

  public BikeRentalResponse getBikeRental(int bookingId) throws Exception {
    BikeRentalResponse res;
    BikeRentalByBooking bike = repository.getBikeRental(bookingId);
    if (bike == null) {
      throw new Exception("Booking not found [" + bookingId + "]");
    }
    res = new BikeRentalResponse();
    res.setBookingId(bike.getBooking_id());
    res.setBookingDate(bike.getType());
    RentalPeriodVo period = new RentalPeriodVo();
    period.setStartRentDate(bike.getStart_date());
    period.setEndRentDate(bike.getEnd_date());
    StationLocationVo stsOri = new StationLocationVo();
    stsOri.setCode(bike.getOrigin_id());
    stsOri.setName(bike.getOrigin_name());
    stsOri.setLocation(bike.getOrigin_location());
    StationLocationVo stsDes = new StationLocationVo();
    stsDes.setCode(bike.getDestination_id());
    stsDes.setName(bike.getDestination_name());
    stsDes.setLocation(bike.getDestination_name());
    StationVo station = new StationVo();
    station.setOrigin(stsOri);
    station.setDestination(stsDes);
    BikeVo bvo = new BikeVo();
    bvo.setType(bike.getType());
    bvo.setBrand(bike.getBrand());
    bvo.setPriceByMinute(new BigDecimal(bike.getPrice_by_minute()));
    res.setRentalPeriod(period);
    res.setStations(station);
    res.setBike(bvo);

    return res;
  }

}
