package pe.com.example.bikerental.thirdparty;

import java.io.Serializable;

public class Booking implements Serializable {

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  private String booking_id;
  private boolean is_canceled;
  private String created_at;
  private String user_id;
  private String bike_id;


  public String getBooking_id() {
    return this.booking_id;
  }

  public void setBooking_id(String booking_id) {
    this.booking_id = booking_id;
  }

  public boolean isIs_canceled() {
    return this.is_canceled;
  }

  public boolean IsCanceled() {
    return this.is_canceled;
  }

  public void setIsCanceled(boolean is_canceled) {
    this.is_canceled = is_canceled;
  }

  public String getCreated_at() {
    return this.created_at;
  }

  public void setCreated_at(String created_at) {
    this.created_at = created_at;
  }

  public String getUser_id() {
    return this.user_id;
  }

  public void setUser_id(String user_id) {
    this.user_id = user_id;
  }

  public String getBike_id() {
    return this.bike_id;
  }

  public void setBike_id(String bike_id) {
    this.bike_id = bike_id;
  }


}