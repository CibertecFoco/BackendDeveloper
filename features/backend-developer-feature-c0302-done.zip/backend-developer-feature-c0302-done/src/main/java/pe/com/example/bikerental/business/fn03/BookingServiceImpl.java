package pe.com.example.bikerental.business.fn03;

import java.sql.SQLException;
import org.springframework.stereotype.Service;
import pe.com.example.bikerental.models.fn03.request.RentalBikeRequest;

@Service
public class BookingServiceImpl implements BookingService {

  private final BookingRepository repository;

  public BookingServiceImpl(BookingRepository repository) {
    this.repository = repository;
  }

  @Override
  public void createNewBooking(RentalBikeRequest payload) throws SQLException {
    repository.createBookingAndDetails(payload);

  }

}