package pe.com.example.bikerental.business.fn07;

import static pe.com.example.bikerental.constants.QueryStatement.QUERY_CANCELLING_BOOKING;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import pe.com.example.api.database.JdbcUtil;

@Component
public class CancellingBookingRepository {

  private static final Logger log = LoggerFactory.getLogger(CancellingBookingRepository.class);

  private final JdbcUtil db;

  public CancellingBookingRepository(JdbcUtil db) {
    this.db = db;
  }

  public void cancellingBookingById(int bookingId) throws SQLException {
    try (Connection cn = db.getConnection()) {
      try (PreparedStatement ps = cn.prepareStatement(QUERY_CANCELLING_BOOKING)) {
        ps.setObject(1, bookingId);
        ps.setObject(2, bookingId);
        ps.executeUpdate();
        db.commit(cn);
        log.info("[Cancelling booking] done!");
      }
    }
  }

}