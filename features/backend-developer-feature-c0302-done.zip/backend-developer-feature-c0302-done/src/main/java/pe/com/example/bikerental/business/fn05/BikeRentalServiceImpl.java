package pe.com.example.bikerental.business.fn05;

import org.springframework.stereotype.Service;
import pe.com.example.bikerental.models.fn05.response.BikeRentalResponse;

@Service("BikeRentalService")
public class BikeRentalServiceImpl implements BikeRentalService {

  private final BikeRentalProcess process;

  public BikeRentalServiceImpl(BikeRentalProcess process) {
    this.process = process;
  }

  @Override
  public BikeRentalResponse getBikeRental(int bookingId) throws Exception {
    return process.getBikeRental(bookingId);
  }

}