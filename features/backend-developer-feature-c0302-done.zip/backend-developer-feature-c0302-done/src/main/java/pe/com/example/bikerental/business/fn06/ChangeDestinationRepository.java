package pe.com.example.bikerental.business.fn06;

import static pe.com.example.bikerental.constants.QueryStatement.QUERY_UPDATE_DESTINATION_STATION_BOOKING;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import pe.com.example.api.database.JdbcUtil;
import pe.com.example.bikerental.models.fn06.request.ChangeDestinationRequest;

@Component
public class ChangeDestinationRepository {

  private static final Logger log = LoggerFactory.getLogger(ChangeDestinationRepository.class);

  private final JdbcUtil db;

  public ChangeDestinationRepository(JdbcUtil db) {
    this.db = db;
  }

  public int changeDestionationStation(int bookingId, ChangeDestinationRequest payload)
      throws SQLException {
    int result = 0;
    try (Connection cn = db.getConnection()) {
      try (PreparedStatement ps = cn.prepareStatement(QUERY_UPDATE_DESTINATION_STATION_BOOKING)) {
        ps.setObject(1, payload.getDestination().getStation().getCode());
        ps.setObject(2, bookingId);
        result = ps.executeUpdate();
        db.commit(cn);
        log.info("[update] change destination");
      }
    }
    return result;
  }

}
