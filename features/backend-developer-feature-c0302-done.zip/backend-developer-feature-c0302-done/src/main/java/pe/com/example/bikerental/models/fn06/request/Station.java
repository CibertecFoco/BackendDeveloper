package pe.com.example.bikerental.models.fn06.request;

import static pe.com.example.bikerental.constants.Constants.REGEXP_ALPHANUMERIC;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


public class Station {

  @ApiModelProperty(required = true, value = "identifier destination station id")
  @NotNull
  @NotEmpty
  @Size(min = 5, max = 5)
  @Pattern(regexp = REGEXP_ALPHANUMERIC)
  private String code;

  public String getCode() {
    return this.code;
  }

  public void setCode(String code) {
    this.code = code;
  }
}
