package pe.com.example.bikerental.business.fn05;

import pe.com.example.bikerental.models.fn05.response.BikeRentalResponse;

public interface BikeRentalService {

  BikeRentalResponse getBikeRental(int bookingId) throws Exception;

}