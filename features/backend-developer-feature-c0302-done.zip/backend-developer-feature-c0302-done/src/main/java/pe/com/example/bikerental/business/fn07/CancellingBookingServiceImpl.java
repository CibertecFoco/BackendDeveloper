package pe.com.example.bikerental.business.fn07;

import java.sql.SQLException;
import org.springframework.stereotype.Service;

@Service
public class CancellingBookingServiceImpl implements CancellingBookingService {

  private final CancellingBookingRepository repository;

  public CancellingBookingServiceImpl(CancellingBookingRepository repository) {
    this.repository = repository;
  }

  @Override
  public void cancellingBookingById(int bookingId) throws SQLException {
    repository.cancellingBookingById(bookingId);

  }

}