package pe.com.example.bikerental.business.fn03;

import java.sql.SQLException;
import pe.com.example.bikerental.models.fn03.request.RentalBikeRequest;

/**
 * method interface for create new Booking.
 */
public interface BookingService {

  void createNewBooking(RentalBikeRequest payload) throws SQLException;

}