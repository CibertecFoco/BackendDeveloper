package pe.com.example.rentalbike.models.fn02.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;

@Data
@JsonIgnoreProperties
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BikeQuantityResponse implements Serializable {
  private static final long serialVersionUID = -8857095760200296580L;

  @ApiModelProperty(required = true, value = "code station")
  private String stationId;

  @ApiModelProperty(required = true, value = "Object bike")
  private Bike bike;

}
