package pe.com.example.rentalbike.expose.web;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.util.List;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import pe.com.example.rentalbike.business.fn01.StationAvailableService;
import pe.com.example.rentalbike.business.fn02.BikeQuantityService;
import pe.com.example.rentalbike.models.fn01.response.StationAvailableResponse;
import pe.com.example.rentalbike.models.fn02.response.BikeQuantityResponse;


@Api("Rental Bike Stations")
@RestController
@RequestMapping("/bike/rental-station/v1")
@Slf4j
public class RentalBikeController {

  private StationAvailableService stationAvailableService;

  private BikeQuantityService bikeQuantityService;


  /**
   * @param stationAvailableService
   * @param bikeQuantityService
   */
  public RentalBikeController(
      StationAvailableService stationAvailableService,
      BikeQuantityService bikeQuantityService) {
    this.bikeQuantityService = bikeQuantityService;
    this.stationAvailableService = stationAvailableService;
  }

  /**
   * method for return list of stations.
   *
   * @return List
   */
  @ApiOperation(
      value = "Get list stations available.",
      produces = MediaType.APPLICATION_JSON_VALUE,
      consumes = MediaType.APPLICATION_JSON_VALUE,
      response = StationAvailableResponse.class,
      responseContainer = "List",
      httpMethod = "GET")
  @ApiResponses({
    @ApiResponse(
        code = 200,
        message = "Ok",
        response = StationAvailableResponse.class,
        responseContainer = "List")
  })
  @GetMapping(
      value = "/stations",
      consumes = MediaType.APPLICATION_JSON_VALUE,
      produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.OK)
  public List<StationAvailableResponse> listStation() {
    log.info("[station] get station start request");
    return stationAvailableService.getAllStationAvailable();
  }

  /**
   * @param stationId
   * @return
   */
  @ApiOperation(
      value = "Get quantity bikes by station.",
      produces = MediaType.APPLICATION_JSON_VALUE,
      consumes = MediaType.APPLICATION_JSON_VALUE,
      response = BikeQuantityResponse.class,
      responseContainer = "List",
      httpMethod = "GET")
  @ApiResponses({
    @ApiResponse(
        code = 200,
        message = "Ok",
        response = BikeQuantityResponse.class,
        responseContainer = "List")
  })
  @GetMapping(
      value = "/stations/{station_id}",
      consumes = MediaType.APPLICATION_JSON_VALUE,
      produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.OK)
  public List<BikeQuantityResponse> listBikeQuantity(
      @PathVariable(value = "station_id") String stationId) {
    log.info("[bike] get bike quantity request");
    return bikeQuantityService.getStationQuantity(stationId);
  }

}
