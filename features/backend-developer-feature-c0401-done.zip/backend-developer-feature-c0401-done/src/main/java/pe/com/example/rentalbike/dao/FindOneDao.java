package pe.com.example.rentalbike.dao;

public interface FindOneDao<T> {

  <V> T getOne();
}
