package pe.com.example.rentalbike.thirdparty;

import java.io.Serializable;
import lombok.Data;
import pe.com.example.api.db.DBColumn;

@Data
public class Station implements Serializable {

  private static final long serialVersionUID = 7148793598521297654L;

  @DBColumn(columnName = "station_id")
  private String stationId;

  @DBColumn(columnName = "name")
  private String name;

  @DBColumn(columnName = "location")
  private String location;

  @DBColumn(columnName = "is_active")
  private Boolean isActive;
}
