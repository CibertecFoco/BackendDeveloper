package pe.com.example.rentalbike.thirdparty;

import java.io.Serializable;
import lombok.Data;
import pe.com.example.api.db.DBColumn;

@Data
public class DetailStation implements Serializable {

  private static final long serialVersionUID = -2442320298045872942L;

  @DBColumn(columnName = "station_id")
  private Station stationId;

  @DBColumn(columnName = "bike_id")
  private Bike bikeId;

  @DBColumn(columnName = "quantity")
  private Integer quantity;

  @DBColumn(columnName = "is_active")
  private Boolean isActive;
}
