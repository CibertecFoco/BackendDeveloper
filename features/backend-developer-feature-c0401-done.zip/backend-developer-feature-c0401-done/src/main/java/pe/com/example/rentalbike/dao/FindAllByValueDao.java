package pe.com.example.rentalbike.dao;

import java.sql.SQLException;
import java.util.Collection;

public interface FindAllByValueDao<T> {

  <V extends String> Collection<T> getAll(V value) throws SQLException;
}
