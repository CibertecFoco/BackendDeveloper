package pe.com.example.api.config;


import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
@Getter
@Setter
public class ApplicationConfiguration {

  @Value("${application.datasource.username:sa}")
  private String h2User;

  @Value("${application.datasource.passwd:1234}")
  private String h2Passwd;

  @Value("${application.datasource.url:jdbc:h2:./db/bike}")
  private String h2Url;

}