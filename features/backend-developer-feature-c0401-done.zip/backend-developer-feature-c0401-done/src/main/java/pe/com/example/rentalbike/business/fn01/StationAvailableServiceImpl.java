package pe.com.example.rentalbike.business.fn01;

import java.util.List;
import org.springframework.stereotype.Service;
import pe.com.example.rentalbike.models.fn01.response.StationAvailableResponse;

@Service
public class StationAvailableServiceImpl implements StationAvailableService {

  private StationAvailableProcess process;

  public StationAvailableServiceImpl(StationAvailableProcess process) {
    this.process = process;
  }

  @Override
  public List<StationAvailableResponse> getAllStationAvailable() {
    return process.processAvailableStation();
  }
}
