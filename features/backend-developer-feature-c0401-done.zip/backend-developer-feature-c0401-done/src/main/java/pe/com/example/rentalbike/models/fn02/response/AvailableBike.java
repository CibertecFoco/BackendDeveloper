package pe.com.example.rentalbike.models.fn02.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AvailableBike {

  @ApiModelProperty(example = "1", required = true, value = "quantity bikes available")
  private int quantity;
}
