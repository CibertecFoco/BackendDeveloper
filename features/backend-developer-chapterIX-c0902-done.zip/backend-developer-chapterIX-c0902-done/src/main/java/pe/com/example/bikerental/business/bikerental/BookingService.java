package pe.com.example.bikerental.business.bikerental;

import java.util.function.Function;
import pe.com.example.bikerental.models.api.fn03.request.RentalBikeRequest;
import pe.com.example.bikerental.models.api.fn03.request.BikeRentalResponse;
import reactor.core.publisher.Mono;

/**
 * method interface for create new Booking.
 */
public interface BookingService {

  Function<RentalBikeRequest, Mono<BikeRentalResponse>> createBikeRental();

}