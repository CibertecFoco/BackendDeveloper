package pe.com.example.bikerental.business.bikerental;

import java.util.function.Function;
import org.springframework.stereotype.Service;
import pe.com.example.bikerental.models.api.fn03.request.BikeRentalResponse;
import pe.com.example.bikerental.models.api.fn03.request.RentalBikeRequest;
import reactor.core.publisher.Mono;

@Service
public class BookingServiceImpl implements BookingService {

  private final RentalCreationSender sender;

  public BookingServiceImpl(final RentalCreationSender sender) {
    this.sender = sender;
  }

  @Override
  public Function<RentalBikeRequest, Mono<BikeRentalResponse>> createBikeRental() {
    return (payload) -> sender.createBookingAndDetails().apply(payload);
  }

}
