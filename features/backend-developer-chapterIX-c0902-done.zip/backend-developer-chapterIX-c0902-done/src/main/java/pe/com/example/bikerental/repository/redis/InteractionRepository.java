package pe.com.example.bikerental.repository.redis;

import java.util.UUID;
import org.springframework.data.redis.core.ReactiveRedisOperations;
import org.springframework.stereotype.Repository;
import pe.com.example.bikerental.thirdparty.redis.InteractionDto;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public class InteractionRepository {

  private final ReactiveRedisOperations<String, Object> opsTemplate;

  /**
   * @param opsTemplate
   */
  public InteractionRepository(ReactiveRedisOperations<String, Object> opsTemplate) {
    this.opsTemplate = opsTemplate;
  }

  public Mono<InteractionDto> save(InteractionDto interaction) {
    interaction.setId(UUID.randomUUID().toString());
    //
    // opsTemplate.opsForValue().append(String.format("history:userId:%s", interaction.getUserId()), interaction.getId())
    return opsTemplate.opsForHash()
        .put(String.format("history:%s", interaction.getId()), interaction.getId(), interaction)
        .flatMap((data) -> opsTemplate.opsForSet().add(String.format("history:userId:%s:idx", interaction.getUserId()), interaction.getId()))
        .flatMap((test) -> Mono.just(interaction));
  }

  public Flux<InteractionDto> findByUserId(String userId) {
    return opsTemplate.opsForSet().members(String.format("history:userId:%s:idx", userId))
        .cast(String.class)
        .flatMap((data) -> opsTemplate.opsForHash().values(String.format("history:%s", data))).cast(InteractionDto.class);

  }

}
