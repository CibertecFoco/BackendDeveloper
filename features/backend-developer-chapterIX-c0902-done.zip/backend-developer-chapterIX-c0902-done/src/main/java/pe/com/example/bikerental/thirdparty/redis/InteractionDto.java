package pe.com.example.bikerental.thirdparty.redis;

import java.io.Serializable;
import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.index.Indexed;

@RedisHash(value = "history")
public class InteractionDto implements Serializable {

  /**
   *
   */
  private static final long serialVersionUID = 2848075921546770866L;

  @Id
  private String id;

  private int bookingId;

  @Indexed
  private String userId;

  private HistoryStatus status;

  private String registerDate;


  /**
   * @return the bookingId
   */
  public int getBookingId() {
    return bookingId;
  }

  /**
   * @return the userId
   */
  public String getUserId() {
    return userId;
  }

  /**
   * @param userId the userId to set
   */
  public void setUserId(String userId) {
    this.userId = userId;
  }

  /**
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * @param id the id to set
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * @return the registerDate
   */
  public String getRegisterDate() {
    return registerDate;
  }

  /**
   * @param registerDate the registerDate to set
   */
  public void setRegisterDate(String registerDate) {
    this.registerDate = registerDate;
  }

  /**
   * @return the status
   */
  public HistoryStatus getStatus() {
    return status;
  }

  /**
   * @param status the status to set
   */
  public void setStatus(HistoryStatus status) {
    this.status = status;
  }

  /**
   * @param bookingId the bookingId to set
   */
  public void setBookingId(int bookingId) {
    this.bookingId = bookingId;
  }

}