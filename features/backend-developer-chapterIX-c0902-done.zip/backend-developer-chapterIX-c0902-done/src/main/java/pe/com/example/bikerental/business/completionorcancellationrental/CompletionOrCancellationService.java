package pe.com.example.bikerental.business.completionorcancellationrental;

import java.util.Map;
import reactor.core.publisher.Mono;

public interface CompletionOrCancellationService {

  Mono<Void> completionOrCancellationRentalByRentId(Map<String, Object> rental);

}