package pe.com.example.bikerental.expose.web;

import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import pe.com.example.bikerental.business.bikerental.BookingService;
import pe.com.example.bikerental.business.completionorcancellationrental.CompletionOrCancellationService;
import pe.com.example.bikerental.business.interactions.InteractionService;
import pe.com.example.bikerental.models.api.fn03.request.RentalBikeRequest;
import pe.com.example.bikerental.thirdparty.redis.HistoryStatus;
import pe.com.example.bikerental.thirdparty.redis.InteractionDto;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/bike-rental/flux/v1")
public class CacheController {

  private static final Logger log = LoggerFactory.getLogger(CacheController.class);

  private final BookingService bookingService;
  private final CompletionOrCancellationService corcService;
  private final InteractionService interactionService;

  public CacheController(BookingService bookingService, InteractionService interactionService,
      CompletionOrCancellationService corcService) {
    this.bookingService = bookingService;
    this.interactionService = interactionService;
    this.corcService = corcService;
  }

  @PostMapping(value = "/rents", consumes = {MediaType.APPLICATION_JSON_VALUE},
      produces = {MediaType.APPLICATION_JSON_VALUE})
  @ResponseStatus(HttpStatus.CREATED)
  public Mono<?> createBooking(@RequestBody RentalBikeRequest payload) throws Exception {
    return bookingService.createBikeRental().apply(payload);
  }

  @PatchMapping(value = "/rents/{bookingId}", consumes = {MediaType.APPLICATION_JSON_VALUE},
      produces = {MediaType.APPLICATION_JSON_VALUE})
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public Mono<Void> completingBikeBooking(@PathVariable("bookingId") Integer bookingId) throws Exception {
    log.info("[starting completing booking]");
    return corcService.completionOrCancellationRentalByRentId(Map.of("rentId", bookingId, "interaction", HistoryStatus.COMPLETED));
  }

  @DeleteMapping(value = "/rents/{bookingId}", consumes = {MediaType.APPLICATION_JSON_VALUE},
      produces = {MediaType.APPLICATION_JSON_VALUE})
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public Mono<Void> cancellingBikeBooking(@PathVariable("bookingId") Integer bookingId) throws Exception {
    log.info("[starting cancelling booking]");
    return corcService
        .completionOrCancellationRentalByRentId(Map.of("rentId", bookingId, "interaction", HistoryStatus.CANCELLING));
  }

  @GetMapping(value = "/histories/{userId}", produces = {MediaType.APPLICATION_STREAM_JSON_VALUE})
  @ResponseStatus(HttpStatus.OK)
  public Flux<InteractionDto> getHistoryInteractionByUserId(@PathVariable("userId") String userId) {
    return interactionService.getHistoryByUserId(userId);
  }

}
