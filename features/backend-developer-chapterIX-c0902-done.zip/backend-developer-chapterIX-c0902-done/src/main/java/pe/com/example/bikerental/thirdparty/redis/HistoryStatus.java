package pe.com.example.bikerental.thirdparty.redis;

public enum HistoryStatus {

  REGISTER,
  CANCELLING,
  COMPLETED;

}