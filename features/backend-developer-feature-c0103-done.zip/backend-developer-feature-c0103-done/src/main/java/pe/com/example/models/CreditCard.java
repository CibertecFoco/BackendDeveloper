package pe.com.example.models;

import java.math.BigDecimal;

public class CreditCard {

  private String creditCardId;

  private String brand;

  private BigDecimal amount;

  public String getCreditCardId() {
    return creditCardId;
  }

  public void setCreditCardId(String creditCardId) {
    this.creditCardId = creditCardId;
  }

  public String getBrand() {
    return brand;
  }

  public void setBrand(String brand) {
    this.brand = brand;
  }

  public BigDecimal getAmount() {
    return amount;
  }

  public void setAmount(BigDecimal amount) {
    this.amount = amount;
  }

  @Override
  public String toString() {
    return String.format("%s %s %.2f", this.getCreditCardId(), this.getBrand(), this.getAmount());
  }
}
