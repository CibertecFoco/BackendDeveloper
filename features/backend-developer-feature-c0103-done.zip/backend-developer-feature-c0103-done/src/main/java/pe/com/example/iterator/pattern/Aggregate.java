package pe.com.example.iterator.pattern;

public interface Aggregate {

  public Iterator createIterator();

}
