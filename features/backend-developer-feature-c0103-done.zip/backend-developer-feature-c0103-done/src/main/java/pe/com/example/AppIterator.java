package pe.com.example;

import java.math.BigDecimal;
import pe.com.example.iterator.pattern.CreditCardArray;
import pe.com.example.iterator.pattern.Iterator;
import pe.com.example.models.CreditCard;

public class AppIterator {

  public static void main(String[] args) {

    CreditCard cc1 = new CreditCard();
    cc1.setAmount(BigDecimal.valueOf(2000));
    cc1.setBrand("VISA");
    cc1.setCreditCardId("409212312341234");

    CreditCard cc2 = new CreditCard();
    cc2.setAmount(BigDecimal.valueOf(4000));
    cc2.setBrand("AMEX");
    cc2.setCreditCardId("39212312341212");

    CreditCard creditCards[] = {cc1, cc2};

    CreditCardArray ccarr = new CreditCardArray(creditCards);

    for (Iterator it = ccarr.createIterator(); it.hasNext();) {
      System.out.println(it.next());
    }
  }
}
