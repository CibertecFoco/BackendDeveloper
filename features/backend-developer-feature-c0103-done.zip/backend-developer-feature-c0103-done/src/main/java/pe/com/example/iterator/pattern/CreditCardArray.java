package pe.com.example.iterator.pattern;


import pe.com.example.models.CreditCard;

public class CreditCardArray implements Aggregate {

  private CreditCard creditCards[];

  public CreditCardArray(CreditCard[] creditCards) {
    this.creditCards = creditCards;
  }

  @Override
  public Iterator createIterator() {
    return (Iterator) new CreditCardArrayIterator();
  }

  private class CreditCardArrayIterator implements Iterator {

    private int position;

    @Override
    public Object next() {
      if (this.hasNext()) {
        return creditCards[position++];
      } else {
        return null;
      }
    }

    @Override
    public boolean hasNext() {
      return (position < creditCards.length);
    }
  }
}
