package pe.com.example.iterator.pattern;

public interface Iterator {

  public Object next();

  public boolean hasNext();

}
