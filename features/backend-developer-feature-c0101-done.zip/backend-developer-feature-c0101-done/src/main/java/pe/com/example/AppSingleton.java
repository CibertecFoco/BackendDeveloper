package pe.com.example;

import pe.com.example.singleton.pattern.Logger;

public class AppSingleton {

  public static void main(String[] args) {

    // Se obtiene la primera instancia de la clase Logger, esta instancia mostrará el mensaje del constructor pero no
    // se mostrará en las siguientes instancias.
    Logger logger1 = Logger.getInstance();

    Logger logger2 = Logger.getInstance();

    Logger logger3 = Logger.getInstance();

    logger1.info("0001");
    logger2.warn("0002");
    logger1.warn("0002");
    logger3.info("0004");
    logger2.error("0005");
    logger3.debug("este es un comentario para el debug");

  }
}
