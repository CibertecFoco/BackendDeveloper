package pe.com.example.singleton.pattern;

/**
 *
 */
public final class Logger extends LoggerAbstract {

  private static Logger instance;

  private Logger() {
    System.out.println("[Pattern Singleton] Se crea la única instancia de la clase Logger. ");
  }

  /**
   *
   * @return {@link Logger}
   */
  public static synchronized Logger getInstance() {
    if (null == instance) {
      instance = new Logger();
    }
    return instance;
  }
}
