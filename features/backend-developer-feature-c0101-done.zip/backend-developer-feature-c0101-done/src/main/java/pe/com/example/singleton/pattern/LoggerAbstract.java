package pe.com.example.singleton.pattern;

import static pe.com.example.constants.Constants.DEBUG_LOG;
import static pe.com.example.constants.Constants.ERROR_LOG;
import static pe.com.example.constants.Constants.FORMAT_DATETIME_ISO;
import static pe.com.example.constants.Constants.FORMAT_LOG;
import static pe.com.example.constants.Constants.INFO_LOG;
import static pe.com.example.constants.Constants.WARN_LOG;
import static pe.com.example.constants.Constants.ZONE_ID;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

class LoggerAbstract {

  protected final LocalDateTime dateTime;

  protected LoggerAbstract() {
    this.dateTime = LocalDateTime.now(ZoneId.of(ZONE_ID));
  }

  /**
   *
   * @return {@link LocalDateTime}
   */
  private LocalDateTime getDateTime() {
    return this.dateTime;
  }

  /**
   *
   * @param type String
   * @param message String
   */
  private synchronized void printMessage(String type, String message) {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern(FORMAT_DATETIME_ISO);
    System.out.println(String.format(FORMAT_LOG, getDateTime().format(dtf), type, message));
  }

  public void info(String message) {
    this.printMessage(INFO_LOG, message);
  }

  public void warn(String message) {
    this.printMessage(WARN_LOG, message);
  }

  public void debug(String message) {
    this.printMessage(DEBUG_LOG, message);
  }

  public void error(String message) {
    this.printMessage(ERROR_LOG, message);
  }
}