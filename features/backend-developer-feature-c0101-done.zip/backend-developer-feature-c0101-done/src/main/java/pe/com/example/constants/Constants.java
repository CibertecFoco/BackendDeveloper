package pe.com.example.constants;

public final class Constants {

  public static final String ZONE_ID = "America/Lima";
  public static final String FORMAT_DATETIME_ISO = "yyyy-MM-dd hh:mm:ss a";
  public static final String FORMAT_LOG = "%s %s %s";
  public  static final String INFO_LOG = "[INFO]";
  public  static final String WARN_LOG = "[WARN]";
  public  static final String DEBUG_LOG = "[DEBUG]";
  public  static final String ERROR_LOG = "[ERROR]";
}
