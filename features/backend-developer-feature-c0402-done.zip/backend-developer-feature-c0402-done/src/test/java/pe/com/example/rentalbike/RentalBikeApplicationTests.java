package pe.com.example.rentalbike;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentalBikeApplicationTests {

	@Test
	void contextLoads() {
	}

}
