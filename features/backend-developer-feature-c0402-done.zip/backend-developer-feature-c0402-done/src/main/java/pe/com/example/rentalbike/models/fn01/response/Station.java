package pe.com.example.rentalbike.models.fn01.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Station implements Serializable {

  private static final long serialVersionUID = -405110605808658791L;

  @ApiModelProperty(example = "S0001", required = true, value = "station id")
  private String code;

  @ApiModelProperty(example = "Central Park", required = true, value = "name of station")
  private String name;

  @ApiModelProperty(
      example = "15.22654 -78.656241",
      required = true,
      value = "location of station in latitude and longitude")
  private String location;


}
