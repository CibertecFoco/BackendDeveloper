package pe.com.example.rentalbike.constants.util;

import static pe.com.example.rentalbike.constants.Constants.DATE_FULL_ISO;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

public final class Utils {

  /**
   * method for convert timestamp to string with format ISO8006.
   * @param time timestamp
   * @return String
   */
  public static final String convertToString(Timestamp time) {
    if (null != time) {
      Date date = new Date();
      date.setTime(time.getTime());
      SimpleDateFormat format = new SimpleDateFormat(DATE_FULL_ISO);
      return format.format(date);
    }
    return "";
  }
}
