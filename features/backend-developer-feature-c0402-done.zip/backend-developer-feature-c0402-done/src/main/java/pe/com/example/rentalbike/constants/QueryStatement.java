package pe.com.example.rentalbike.constants;

public final class QueryStatement {

  public static final String QUERY_STATIONS_AVAILABLE =
      "SELECT * FROM STATION WHERE is_active = true;";

  public static final String QUERY_QUANTITY_BIKES_BY_STATIONS_AVAILABLE =
      "SELECT d.station_id, d.bike_id, b.type, b.brand, d.quantity, b.price_by_minute"
          + " FROM DETAILSTATIONS d INNER JOIN BIKE b ON b.bike_id = d.bike_id WHERE d.station_id = :station_id;";

}
