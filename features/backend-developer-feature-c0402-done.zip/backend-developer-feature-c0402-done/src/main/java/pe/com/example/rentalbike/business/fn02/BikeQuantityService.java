package pe.com.example.rentalbike.business.fn02;

import java.util.List;
import pe.com.example.rentalbike.models.fn02.response.BikeQuantityResponse;

public interface BikeQuantityService {

  List<BikeQuantityResponse> getStationQuantity(String stationId);

}
