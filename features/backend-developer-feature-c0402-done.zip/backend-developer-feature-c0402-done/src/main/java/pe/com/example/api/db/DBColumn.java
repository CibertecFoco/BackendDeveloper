package pe.com.example.api.db;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface DBColumn {

  /**
   * column name
   * @return String
   */
  String columnName();

}
