package pe.com.example.api.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
@Getter
@Setter
public class ApplicationConfiguration {

  @Value("${application.datasource.username}")
  private String h2User;

  @Value("${application.datasource.passwd}")
  private String h2Passwd;

  @Value("${application.datasource.url}")
  private String h2Url;


  @Value("${springfox.documentation.swagger.description}")
  private String swaggerDescription;

  @Value("${springfox.documentation.swagger.version}")
  private String swaggerVersion;

}
