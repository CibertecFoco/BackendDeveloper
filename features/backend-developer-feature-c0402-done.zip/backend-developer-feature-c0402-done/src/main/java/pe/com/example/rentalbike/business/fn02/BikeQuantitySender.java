package pe.com.example.rentalbike.business.fn02;

import static pe.com.example.rentalbike.constants.QueryStatement.QUERY_QUANTITY_BIKES_BY_STATIONS_AVAILABLE;

import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import pe.com.example.api.db.DbManage;
import pe.com.example.rentalbike.dao.FindAllByValueDao;
import pe.com.example.rentalbike.thirdparty.dto.BikeQuantity;

@Component
@Slf4j
public class BikeQuantitySender implements FindAllByValueDao<BikeQuantity> {

  private DbManage db;

  public BikeQuantitySender(DbManage db) {
    this.db = db;
  }

  @Override
  public <V extends String> Collection<BikeQuantity> getAll(V value) {
    try {
      Map<String, Object> params = new HashMap<>();
      params.put("station_id", value);
      return db.getData(QUERY_QUANTITY_BIKES_BY_STATIONS_AVAILABLE, params, BikeQuantity.class);
    } catch (SQLException ex) {
      log.error(ex.getMessage());
    }
    return null;
  }
}
