package pe.com.example.rentalbike.thirdparty;

import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Data;
import pe.com.example.api.db.DBColumn;

@Data
public class Bike implements Serializable {

  private static final long serialVersionUID = 7069630565360912839L;

  @DBColumn(columnName = "bike_id")
  private String bikeId;

  @DBColumn(columnName = "type")
  private String type;

  @DBColumn(columnName = "brand")
  private String brand;

  @DBColumn(columnName = "is_active")
  private Boolean isActive;

  @DBColumn(columnName = "price_by_minute")
  private BigDecimal priceByMinute;
}
