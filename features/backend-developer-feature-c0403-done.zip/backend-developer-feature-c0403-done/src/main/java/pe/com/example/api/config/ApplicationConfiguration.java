package pe.com.example.api.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Getter
@Setter
@Profile({"cer", "pro"})
public class ApplicationConfiguration {

  @Value("${application.datasource.username:}")
  private String h2User;

  @Value("${application.datasource.passwd:}")
  private String h2Passwd;

  @Value("${application.datasource.url:}")
  private String h2Url;


  @Value("${springfox.documentation.swagger.description:}")
  private String swaggerDescription;

  @Value("${springfox.documentation.swagger.version:0.0.1-SNAPSHOT}")
  private String swaggerVersion;

}
