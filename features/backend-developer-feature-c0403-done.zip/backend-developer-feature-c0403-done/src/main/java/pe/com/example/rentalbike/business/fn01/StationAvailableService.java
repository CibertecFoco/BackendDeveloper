package pe.com.example.rentalbike.business.fn01;

import java.util.List;
import pe.com.example.rentalbike.models.fn01.response.StationAvailableResponse;

public interface StationAvailableService {

  List<StationAvailableResponse> getAllStationAvailable();

}
