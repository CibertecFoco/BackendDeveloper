package pe.com.example.rentalbike.business.fn01;

import static pe.com.example.rentalbike.constants.QueryStatement.QUERY_STATIONS_AVAILABLE;

import java.sql.SQLException;
import java.util.Collection;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import pe.com.example.api.db.DbManage;
import pe.com.example.api.db.RepositoryManager;
import pe.com.example.rentalbike.dao.FindAllDao;
import pe.com.example.rentalbike.thirdparty.Station;

@Slf4j
@Component
public class StationAvailableSender implements FindAllDao<Station> {

  private RepositoryManager repository;

  public StationAvailableSender(RepositoryManager repository) {
    this.repository = repository;
  }

  @Override
  public Collection<Station> getAll() {
    try {
      return repository.getData(QUERY_STATIONS_AVAILABLE, null, Station.class);
    } catch (SQLException ex) {
      log.error(ex.getMessage());
    }
    return null;
  }
}
