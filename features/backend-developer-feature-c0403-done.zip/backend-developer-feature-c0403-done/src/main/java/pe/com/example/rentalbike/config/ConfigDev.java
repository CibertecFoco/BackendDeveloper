package pe.com.example.rentalbike.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import pe.com.example.api.config.ApplicationConfiguration;

@Configuration
public class ConfigDev {

  @Bean()
  @Profile("dev")
  public ApplicationConfiguration getConfiguration() {
    ApplicationConfiguration developmentConf = new ApplicationConfiguration();
    developmentConf.setSwaggerDescription("Rental Bike Desa");
    developmentConf.setSwaggerVersion("0.0.1-SNAPSHOT");
    return developmentConf;
  }

}