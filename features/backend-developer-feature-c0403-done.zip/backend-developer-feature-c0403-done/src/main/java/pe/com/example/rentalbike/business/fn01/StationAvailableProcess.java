package pe.com.example.rentalbike.business.fn01;

import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import pe.com.example.rentalbike.models.fn01.response.StationAvailableResponse;
import pe.com.example.rentalbike.thirdparty.Station;

@Component
@Slf4j
public class StationAvailableProcess {

  private StationAvailableSender sender;

  public StationAvailableProcess(StationAvailableSender sender) {
    this.sender = sender;
  }

  /**
   * method process for get all stations available.
   * @return List
   */
  public List<StationAvailableResponse> processAvailableStation() {
    List<StationAvailableResponse> lst = new ArrayList<>();
    StationAvailableResponse res;
    for (Station station : sender.getAll()) {
      res = new StationAvailableResponse();
      pe.com.example.rentalbike.models.fn01.response.Station sts =
          new pe.com.example.rentalbike.models.fn01.response.Station();
      sts.setCode(station.getStationId());
      sts.setName(station.getName());
      sts.setLocation(station.getLocation());
      res.setStation(sts);
      lst.add(res);
    }
    return lst;
  }
}
