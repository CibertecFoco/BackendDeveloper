package pe.com.example.api.db;

import static pe.com.example.api.Constants.DELIMINATOR_NAMED_QUERY_PARAMETER;
import static pe.com.example.api.Constants.NAMED_KEY_PARAMS;
import static pe.com.example.api.Constants.NAMED_KEY_QUERY;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import org.springframework.util.ReflectionUtils;

@Component
@Slf4j
@Profile({"cer", "pro"})
public class DbManage implements RepositoryManager {

  private JdbcUtil jdbcUtil;

  public DbManage(JdbcUtil jdbcUtil) {
    this.jdbcUtil = jdbcUtil;
  }

  /**
   * @param query
   * @param params
   * @param <T>
   * @return int
   * @throws SQLException
   */
  public <T> int execute(String query, Map<String, Object> params) throws SQLException {
    try (Connection cn = jdbcUtil.getConnection()) {
      Map<String, Object> parser = parseQuery(query, params);
      try (PreparedStatement pstmt =
          cn.prepareStatement(String.valueOf(parser.get(NAMED_KEY_QUERY)))) {
        return namedPreparedStatementUpdate(
            pstmt, (Map<Integer, Object>) parser.get(NAMED_KEY_PARAMS));
      }
    }
  }

  /**
   * @param query
   * @param params
   * @param type
   * @param <T>
   * @return List
   * @throws SQLException
   */
  public <T> List<T> getData(String query, Map<String, Object> params, Class<T> type)
      throws SQLException {
    try (Connection cn = jdbcUtil.getConnection()) {
      Map<String, Object> parser = parseQuery(query, params);
      try (PreparedStatement pstmt =
          cn.prepareStatement(String.valueOf(parser.get(NAMED_KEY_QUERY)))) {
        ResultSet rs =
            namedPreparedStatementResultSet(
                pstmt, (Map<Integer, Object>) parser.get(NAMED_KEY_PARAMS));
        List<T> list = new ArrayList<>();
        while (rs.next()) {
          T t = type.getConstructor().newInstance();
          loadResultSetIntoObject(rs, t);
          list.add(t);
        }
        return list;
      }
    } catch (InstantiationException
        | InvocationTargetException
        | NoSuchMethodException
        | IllegalAccessException e) {
      log.error(e.getMessage());
    }

    return new ArrayList<>();
  }

  public <T> T getOneData(String query, Map<String, Object> params, Class<T> type)
      throws SQLException {
    Iterator<T> element = this.getData(query, params, type).iterator();
    if (element.hasNext()) {
      return element.next();
    }
    throw new SQLException("No value");
  }

  /**
   * @param rst
   * @param object
   * @throws IllegalArgumentException
   * @throws IllegalAccessException
   * @throws SQLException
   */
  private void loadResultSetIntoObject(ResultSet rst, Object object)
      throws IllegalArgumentException, IllegalAccessException, SQLException {
    Class<?> zclass = object.getClass();

    Field[] allFields =
        Stream.of(zclass.getSuperclass().getDeclaredFields(), zclass.getDeclaredFields())
            .flatMap(Stream::of)
            .toArray(Field[]::new);
    log.info("[fields] {}", Arrays.toString(allFields));
    for (Field field : allFields) {
      ReflectionUtils.makeAccessible(field);
      DBColumn column = field.getAnnotation(DBColumn.class);
      if (ObjectUtils.isEmpty(column)) {
        continue;
      }
      try {
        Object value = rst.getObject(column.columnName());
        // Class<?> type = field.getType();
        field.set(object, value);
      } catch (Exception ex) {
        log.error("[RS] {}", ex.getMessage());
      }
    }
  }

  /**
   * @param query
   * @param params
   * @return
   */
  private Map<String, Object> parseQuery(String query, Map<String, Object> params) {
    Map<Integer, Object> parameters = new HashMap<>();
    String queryToLower = query.toLowerCase().trim();
    int length = queryToLower.length();
    StringBuilder parseQuery = new StringBuilder(length);
    int index = 1;
    for (int i = 0; i < length; i++) {
      char c = queryToLower.charAt(i);
      if (DELIMINATOR_NAMED_QUERY_PARAMETER == c) {
        log.info("[db manage] index primary : {}", i);
        Character.isJavaIdentifierStart(queryToLower.charAt(i + 1));
        int j = i + 2;
        while (j < length && Character.isJavaIdentifierPart(queryToLower.charAt(j))) {
          j++;
        }
        log.info("[db manage] index secondary : {}", j);
        String name = query.substring(i + 1, j);
        log.info("[db manage] parameter name : {}", name);
        c = '?';
        i = name.length() + i;
        parameters.put(index, params.get(name));
        index++;
      }
      parseQuery.append(c);
    }
    Map<String, Object> named = new HashMap<>();
    named.put(NAMED_KEY_QUERY, parseQuery.toString());
    log.info("[SQL] {}", parseQuery.toString());
    named.put(NAMED_KEY_PARAMS, parameters);
    log.info("[SQL] parameters {}", Arrays.toString(parameters.values().toArray()));
    return named;
  }

  /**
   * @param prepared
   * @param params
   * @return
   * @throws SQLException
   */
  private ResultSet namedPreparedStatementResultSet(
      PreparedStatement prepared, Map<Integer, Object> params) throws SQLException {
    if (!ObjectUtils.isEmpty(params)) {
      prepared = setParameters(prepared, params);
    }
    log.info("[Prepared] {}", prepared);
    return prepared.executeQuery();
  }

  /**
   * @param prepared
   * @param params
   * @return
   * @throws SQLException
   */
  private int namedPreparedStatementUpdate(PreparedStatement prepared, Map<Integer, Object> params)
      throws SQLException {
    if (!ObjectUtils.isEmpty(params)) {
      prepared = setParameters(prepared, params);
    }
    log.info("[Prepared] {}", prepared);
    int result = prepared.executeUpdate();
    try {
      jdbcUtil.commit(prepared.getConnection());
      return result;
    } catch (SQLException ex) {
      jdbcUtil.rollback(prepared.getConnection());
      throw ex;
    }
  }

  /**
   * @param prepared
   * @param params
   * @return
   * @throws SQLException
   */
  private PreparedStatement setParameters(PreparedStatement prepared, Map<Integer, Object> params)
      throws SQLException {
    for (Map.Entry<Integer, Object> item : params.entrySet()) {
      log.info("[SQL] Named Parameter {}; {}", item.getKey(), item.getValue());
      prepared.setObject(item.getKey(), item.getValue());
    }
    return prepared;
  }
}
