package pe.com.example.rentalbike.dao;

import java.sql.SQLException;

public interface UpdateDao<T> {

  int update(T t) throws SQLException;

}
