package pe.com.example.api.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import pe.com.example.api.config.ApplicationConfiguration;

@Component
@Slf4j
@Profile({"cer", "pro"})
public class JdbcUtil {

  private ApplicationConfiguration configuration;

  public JdbcUtil(ApplicationConfiguration configuration) {
    log.info("[jdbc] start connection");
    this.configuration = configuration;
  }

  /**
   * method for open connection to Database and disable auto-commit.
   *
   * @return {@link Connection}
   * @throws SQLException
   */
  public Connection getConnection() throws SQLException {
    log.info("[jdbc] starter get connection ");
    Connection cn =
        DriverManager.getConnection(
            configuration.getH2Url(), configuration.getH2User(), configuration.getH2Passwd());
    log.info("[jdbc] connection db!");
    cn.setAutoCommit(false);
    return cn;
  }

  /**
   * method for perform commit sentences
   *
   * @param cn
   */
  public void commit(Connection cn) {
    try {
      if (cn != null) {
        cn.commit();
      }
    } catch (SQLException ex) {
      log.error(ex.getMessage());
    }
  }

  /**
   * method for perform rollback sentences
   *
   * @param cn
   */
  public void rollback(Connection cn) {
    try {
      if (cn != null) {
        cn.rollback();
      }
    } catch (SQLException ex) {
      log.error(ex.getMessage());
    }
  }
}
