package pe.com.example.rentalbike.models.fn01.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;

@Data
@JsonIgnoreProperties
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StationAvailableResponse implements Serializable {

  private static final long serialVersionUID = 3199094195190783422L;

  @ApiModelProperty(required = true)
  private Station station;
}
