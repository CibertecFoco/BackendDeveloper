package pe.com.example.rentalbike.dao;

import java.util.Collection;

public interface FindAllDao<T> {

  Collection<T> getAll();
}
