package pe.com.example.api;

public final class Constants {

  private Constants() {}

  public static final char DELIMINATOR_NAMED_QUERY_PARAMETER = ':';
  public static final String NAMED_KEY_QUERY = "NAMED_QUERY";
  public static final String NAMED_KEY_PARAMS = "NAMED_PARAMS";

}
