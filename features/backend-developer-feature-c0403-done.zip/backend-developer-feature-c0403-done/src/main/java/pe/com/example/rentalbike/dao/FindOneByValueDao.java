package pe.com.example.rentalbike.dao;

public interface FindOneByValueDao<T, V> {

  T getOne(V value) throws Exception;

}
