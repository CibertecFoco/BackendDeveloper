package pe.com.example.rentalbike.business.fn02;

import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import pe.com.example.rentalbike.models.fn02.response.AvailableBike;
import pe.com.example.rentalbike.models.fn02.response.Bike;
import pe.com.example.rentalbike.models.fn02.response.BikeQuantityResponse;
import pe.com.example.rentalbike.thirdparty.dto.BikeQuantity;

@Component
@Slf4j
public class BikeQuantityProcess {

  private BikeQuantitySender sender;

  public BikeQuantityProcess(BikeQuantitySender sender) {
    this.sender = sender;
  }

  /**
   * @param stationId
   * @return List
   */
  public List<BikeQuantityResponse> getBikeAvailable(String stationId) {
    List<BikeQuantityResponse> lst = new ArrayList<>();
    BikeQuantityResponse res;
    for (BikeQuantity bikeQ : sender.getAll(stationId)) {
      res = new BikeQuantityResponse();
      Bike bike = new Bike();
      bike.setCode(bikeQ.getBikeId());
      bike.setType(bikeQ.getType());
      bike.setBrand(bikeQ.getBrand());
      bike.setPriceByMinute(bikeQ.getPriceByMinute());
      AvailableBike availableBike = new AvailableBike();
      availableBike.setQuantity(bikeQ.getQuantity());
      bike.setAvailable(availableBike);
      res.setBike(bike);
      lst.add(res);
    }
    return lst;
  }
}
