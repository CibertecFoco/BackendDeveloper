package pe.com.example.bikerental.business.fn03;

import org.springframework.stereotype.Service;
import pe.com.example.bikerental.models.api.fn03.BikeRentResponse;
import pe.com.example.bikerental.models.api.fn03.BookingRequest;
import reactor.core.publisher.Mono;

/**
 * Class que implementa la lógica de negocio necesaría para procesar la creación de un alquiler de
 * bicicletas y actualizar el estado del alquiler a completado.
 */
@Service
public class BookingServiceImpl implements BookingService {

  private final BikeRentalCompletingSender completingSender;
  private final BikeRentalCreateSender createSender;

  public BookingServiceImpl(BikeRentalCompletingSender completingSender, BikeRentalCreateSender createSender) {
    this.completingSender = completingSender;
    this.createSender = createSender;
  }

  @Override
  public Mono<BikeRentResponse> createBikeBooking(BookingRequest payload) {
    return createSender.createBikeBooking(payload);
  }

  @Override
  public Mono<Void> completeBikeBooking(int bookingId) {
    return completingSender.completeBikeBooking(bookingId);
  }

}
