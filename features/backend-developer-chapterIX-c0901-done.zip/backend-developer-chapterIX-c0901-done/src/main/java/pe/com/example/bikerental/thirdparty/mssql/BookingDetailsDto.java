package pe.com.example.bikerental.thirdparty.mssql;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema = "cibertec", name = "rental_details")
public class BookingDetailsDto {

  @Id
  @Column(name = "booking_id")
  private int bookingId;

  @Column(name = "origin_station_id")
  private String originStationId;

  @Column(name = "destination_station_id")
  private String destinationStationId;

  @Column(name = "start_date")
  private LocalDateTime startDate;

  @Column(name = "end_date")
  private LocalDateTime endDate;

  public int getBookingId() {
    return this.bookingId;
  }

  public void setBookingId(int bookingId) {
    this.bookingId = bookingId;
  }

  public String getOriginStationId() {
    return this.originStationId;
  }

  public void setOriginStationId(String originStationId) {
    this.originStationId = originStationId;
  }

  public String getDestinationStationId() {
    return this.destinationStationId;
  }

  public void setDestinationStationId(String destinationStationId) {
    this.destinationStationId = destinationStationId;
  }

  public LocalDateTime getStartDate() {
    return this.startDate;
  }

  public void setStartDate(LocalDateTime startDate) {
    this.startDate = startDate;
  }

  public LocalDateTime getEndDate() {
    return this.endDate;
  }

  public void setEndDate(LocalDateTime endDate) {
    this.endDate = endDate;
  }

}