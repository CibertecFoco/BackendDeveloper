package pe.com.example.bikerental.business.search;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import pe.com.example.bikerental.repository.mssql.BookingRepository;
import pe.com.example.bikerental.thirdparty.mssql.BookingDto;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

/**
 * BikeRentalSender
 */
@Component
public final class BikeRentalSender {

  private static final Logger log = LoggerFactory.getLogger(BikeRentalSender.class);

  private final BookingRepository bookingRepository;

  public BikeRentalSender(BookingRepository bookingRepository) {
    this.bookingRepository = bookingRepository;
  }


  /**
   * método que nos permite buscar un alquiler en AzureSQL.
   *
   * @param bookingId
   * @return Mono
   */
  public Mono<BookingDto> findBookingById(Integer bookingId) {
    return Mono.defer(() -> {
          log.info("[by find bookingId] {}", bookingId);
          if (bookingId < 0) {
            return Mono.error(new Exception("[find booking] BookingId not valid"));
          }
          return Mono.fromCallable(() -> bookingRepository.findById(bookingId).orElse(new BookingDto()));
        })
        .subscribeOn(Schedulers.elastic())
        .doOnSuccess((dto) -> log.info("[Search booking] found {}", dto.getBookingId()))
        .doOnError((tw) -> log.error("[Search booking] error => {}", tw.getMessage()));
  }

}
