package pe.com.example.bikerental.business.search;

import pe.com.example.bikerental.thirdparty.mssql.BookingDto;
import reactor.core.publisher.Mono;

public interface BikeRentalService {

  Mono<BookingDto> getBikeRentalByBikeRentId(Integer rentId);

}
