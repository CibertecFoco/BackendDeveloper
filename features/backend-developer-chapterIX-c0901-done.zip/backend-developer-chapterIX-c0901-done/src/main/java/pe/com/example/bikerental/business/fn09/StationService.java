package pe.com.example.bikerental.business.fn09;

import pe.com.example.bikerental.thirdparty.mongodb.StationDocument;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;


public interface StationService {

  /**
   * método para consultar las bicicletas por medio de un identificador de estación.
   *
   * @param stationId
   * @return
   */
  Mono<StationDocument> getStationByStationId(String stationId);


  /**
   * método para obtener todas las estaciones con el detalle de bicicletas y sus cantidades.
   *
   * @return
   */
  Flux<StationDocument> getStationAll();

}
