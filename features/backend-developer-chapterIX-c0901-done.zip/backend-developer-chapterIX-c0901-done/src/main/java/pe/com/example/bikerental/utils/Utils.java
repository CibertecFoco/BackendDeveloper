package pe.com.example.bikerental.utils;

import java.time.LocalDateTime;
import java.time.ZoneId;

public final class Utils {

  /**
   * método para obtener la fecha y hora del systema actual.
   *
   * @return LocalDateTime
   */
  public static LocalDateTime getSystemDateTime() {
    return LocalDateTime.now(ZoneId.of("America/Lima"));
  }

}
