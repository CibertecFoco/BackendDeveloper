package pe.com.example.bikerental.models.api.fn03;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.io.Serializable;

@JsonInclude(value = Include.NON_NULL)
public class BikeRentResponse implements Serializable {

  /**
   *
   */
  private static final long serialVersionUID = 3158484307762526405L;

  private int bikeRentId;


  public BikeRentResponse(int bikeRentId) {
    this.bikeRentId = bikeRentId;
  }

  /**
   * @return the bikeRentId
   */
  public int getBikeRentId() {
    return bikeRentId;
  }

  /**
   * @param bikeRentId the bikeRentId to set
   */
  public void setBikeRentId(int bikeRentId) {
    this.bikeRentId = bikeRentId;
  }

}