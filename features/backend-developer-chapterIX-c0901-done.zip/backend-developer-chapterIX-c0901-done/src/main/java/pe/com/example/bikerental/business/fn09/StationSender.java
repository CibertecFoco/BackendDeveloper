package pe.com.example.bikerental.business.fn09;

import java.time.Duration;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.ReactiveMongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;
import pe.com.example.bikerental.thirdparty.mongodb.StationDocument;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Clase que inteactua con MongoDB para poder obtener el detalle actualizado de las cantidad de las
 * bicicletas que contiene cada estación.
 *
 * Para dicho proposito se hace uso de la clase MongoOperations para realizar la consulta sobre una
 * capa más personalizada de la que provee MongoRepository de Spring Data.
 */
@Component
public class StationSender {

  private final static Logger log = LoggerFactory.getLogger(StationSender.class);

  private final ReactiveMongoOperations mongoOps;

  public StationSender(ReactiveMongoOperations mongoOps) {
    this.mongoOps = mongoOps;
  }

  /**
   * método que retorna las bicicletas y sus cantidad, siendo consultadas mediante el identificador de
   * la estación.
   *
   * @See se hace uso de MongoOperations y se aplica Criteria para realizar el filtro.
   *
   * @param stationId Identificador de estación
   * @return StationDocument
   */
  public Mono<StationDocument> getStationById(String stationId) {
    Query query = Query.query(Criteria.where("stationId").is(stationId));
    return mongoOps.findOne(query, StationDocument.class)
        .doOnSuccess((station) -> log.info("[get Station] {}", station));
  }

  /**
   * método que retorna en un listado todas las estaciones que se encuentran en la coleción, con el
   * detalle de las bicicletas y sus cantidades por cada una.
   *
   * Los elementos serán emitidos cada 3000 milisegundos.
   *
   * @See se hace unso de MongoOperations
   *
   * @return Flux<StationDocument>
   */
  public Flux<StationDocument> getAllStation() {
    return mongoOps.findAll(StationDocument.class)
      .delayElements(Duration.ofMillis(3000L));
  }

}
