package pe.com.example.bikerental.business.fn03;

import pe.com.example.bikerental.models.api.fn03.BikeRentResponse;
import pe.com.example.bikerental.models.api.fn03.BookingRequest;
import reactor.core.publisher.Mono;

public interface BookingService {

  /**
   * método que crea un alquiler de bicicletas, interactua con AzureSQL y MongoDb.
   * @param payload {@ BookingRequest}
   * @return Mono
   */
  Mono<BikeRentResponse> createBikeBooking(BookingRequest payload);

  /**
   * método para cambiar el estado de un alquiler a completado, realiza modificaciones sobre AzureSQL y MongoDB
   * @param bookingId int
   * @return Mono
   */
  Mono<Void> completeBikeBooking(int bookingId);

}