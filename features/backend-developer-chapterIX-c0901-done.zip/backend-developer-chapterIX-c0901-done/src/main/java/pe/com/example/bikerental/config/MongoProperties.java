package pe.com.example.bikerental.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "application.mongodb")
public class MongoProperties {

  private String connectionString;

  private String database;

  /**
   * @return the connectionString
   */
  public String getConnectionString() {
    return connectionString;
  }

  /**
   * @return the database
   */
  public String getDatabase() {
    return database;
  }

  /**
   * @param database the database to set
   */
  public void setDatabase(String database) {
    this.database = database;
  }

  /**
   * @param connectionString the connectionString to set
   */
  public void setConnectionString(String connectionString) {
    this.connectionString = connectionString;
  }

}