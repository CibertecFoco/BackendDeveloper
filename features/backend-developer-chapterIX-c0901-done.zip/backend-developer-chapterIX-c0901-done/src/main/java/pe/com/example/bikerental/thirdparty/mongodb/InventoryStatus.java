package pe.com.example.bikerental.thirdparty.mongodb;

public enum InventoryStatus {

  INCREMENT,
  DECREMENT

}