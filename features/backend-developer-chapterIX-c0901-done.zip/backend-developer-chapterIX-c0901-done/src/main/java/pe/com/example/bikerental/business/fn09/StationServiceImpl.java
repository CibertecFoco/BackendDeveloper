package pe.com.example.bikerental.business.fn09;

import org.springframework.stereotype.Service;
import pe.com.example.bikerental.thirdparty.mongodb.StationDocument;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Clase implementadora de la lógica necesario para poder exponer los datos de las estaciones
 * almacenada sobre el collection de mongoDB.
 */
@Service
public class StationServiceImpl implements StationService {

  private StationSender sender;

  public StationServiceImpl(StationSender sender) {
    this.sender = sender;
  }

  @Override
  public Mono<StationDocument> getStationByStationId(String stationId) {
    return sender.getStationById(stationId);
  }

  @Override
  public Flux<StationDocument> getStationAll() {
    return sender.getAllStation();
  }

}
