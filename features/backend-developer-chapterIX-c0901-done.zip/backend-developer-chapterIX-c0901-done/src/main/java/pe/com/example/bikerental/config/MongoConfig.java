package pe.com.example.bikerental.config;

import com.mongodb.ConnectionString;
import com.mongodb.reactivestreams.client.MongoClient;
import com.mongodb.reactivestreams.client.MongoClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.repository.config.EnableReactiveMongoRepositories;

/**
 * clase que configura la conexión hacia MongoBD. Se habilita EnableMongoRepositories para hacer uso
 * de la interfaz MongoRepository, como parte de la abstracción que provee Spring Data.
 */
@Configuration
@EnableJpaRepositories(basePackages = "pe.com.example.bikerental.repository.mssql")
@EnableReactiveMongoRepositories(basePackages = "pe.com.example.bikerental.repository.mongodb")
public class MongoConfig {

  /**
   * Fabrica de conexión para mongodb.
   *
   * @param properties lectura de datos desde el properties.
   * @return MongoClient
   */
  @Bean
  public MongoClient getMongoClient(MongoProperties properties) {
    return MongoClients.create(new ConnectionString(properties.getConnectionString()));
  }

  /**
   * método para exponer ReactiveMongoTemplate para el uso de ReactiveMongoOperations, capa
   * personalizada para el aceceso de datos reactivos desde mongodb.
   *
   * @param properties lectura de datos desde el properties
   * @return MongoTemplate
   */
  @Bean
  public ReactiveMongoTemplate reactiveMongoTemplate(MongoProperties properties) {
    return new ReactiveMongoTemplate(getMongoClient(properties), properties.getDatabase());
  }

}
