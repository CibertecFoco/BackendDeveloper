package pe.com.example.bikerental.repository.mssql;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pe.com.example.bikerental.thirdparty.mssql.BookingDetailsDto;

@Repository
public interface BookingDetailsRepository extends JpaRepository<BookingDetailsDto, Integer> {

}