package pe.com.example.bikerental.models.api.fn03;

import java.io.Serializable;
import java.time.LocalDateTime;

public class BookingRequest implements Serializable {

  /**
   *
   */
  private static final long serialVersionUID = 6591120868471961162L;

  private LocalDateTime startDate;

  private SourceStationVo origin;

  private SourceStationVo destination;

  private BIkeVo bike;

  private String userId;

  public LocalDateTime getStartDate() {
    return this.startDate;
  }

  public void setStartDate(LocalDateTime startDate) {
    this.startDate = startDate;
  }

  public SourceStationVo getOrigin() {
    return this.origin;
  }

  public void setOrigin(SourceStationVo origin) {
    this.origin = origin;
  }

  public SourceStationVo getDestination() {
    return this.destination;
  }

  public void setDestination(SourceStationVo destination) {
    this.destination = destination;
  }

  public BIkeVo getBike() {
    return this.bike;
  }

  public void setBike(BIkeVo bike) {
    this.bike = bike;
  }

  public String getUserId() {
    return this.userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

}