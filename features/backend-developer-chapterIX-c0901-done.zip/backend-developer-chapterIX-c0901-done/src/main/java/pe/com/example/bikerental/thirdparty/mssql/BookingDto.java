package pe.com.example.bikerental.thirdparty.mssql;

import java.io.Serializable;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema = "cibertec", name = "Booking")
public class BookingDto implements Serializable {

  /**
   *
   */
  private static final long serialVersionUID = 5499327492202824093L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "booking_id")
  private int bookingId;

  @Column(name = "is_canceled")
  private boolean canceled;

  @Column(name = "created_at")
  private LocalDateTime createAt;

  @Column(name = "user_id")
  private String userId;

  @Column(name = "bike_id")
  private String bikeId;

  @Column(name = "is_completed")
  private boolean completed;

  @Column(name = "date_completed")
  private LocalDateTime completedDate;

  public int getBookingId() {
    return this.bookingId;
  }

  public void setBookingId(int bookingId) {
    this.bookingId = bookingId;
  }

  public boolean isCanceled() {
    return this.canceled;
  }

  public boolean getCanceled() {
    return this.canceled;
  }

  public void setCanceled(boolean canceled) {
    this.canceled = canceled;
  }

  public LocalDateTime getCreateAt() {
    return this.createAt;
  }

  public void setCreateAt(LocalDateTime createAt) {
    this.createAt = createAt;
  }

  public String getUserId() {
    return this.userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getBikeId() {
    return this.bikeId;
  }

  public void setBikeId(String bikeId) {
    this.bikeId = bikeId;
  }

  public boolean isCompleted() {
    return this.completed;
  }

  public boolean getCompleted() {
    return this.completed;
  }

  public void setCompleted(boolean completed) {
    this.completed = completed;
  }

  public LocalDateTime getCompletedDate() {
    return this.completedDate;
  }

  public void setCompletedDate(LocalDateTime completedDate) {
    this.completedDate = completedDate;
  }


}