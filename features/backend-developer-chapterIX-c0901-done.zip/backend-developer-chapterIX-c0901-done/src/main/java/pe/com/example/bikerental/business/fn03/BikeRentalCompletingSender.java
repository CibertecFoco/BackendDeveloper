package pe.com.example.bikerental.business.fn03;

import static pe.com.example.bikerental.utils.Utils.getSystemDateTime;
import java.util.function.Function;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import pe.com.example.bikerental.business.bikeinventory.BikeInventorySender;
import pe.com.example.bikerental.business.search.BikeRentalService;
import pe.com.example.bikerental.repository.mssql.BookingDetailsRepository;
import pe.com.example.bikerental.repository.mssql.BookingRepository;
import pe.com.example.bikerental.thirdparty.mongodb.InventoryStatus;
import pe.com.example.bikerental.thirdparty.mssql.BookingDetailsDto;
import pe.com.example.bikerental.thirdparty.mssql.BookingDto;
import reactor.core.publisher.Mono;

/**
 * Clase que nos ayuda con las transacciones sobre la base de datos. Para la desarrollo se habilitan
 * dos operaciones crear el alquiler y completar el alquiler. Esto con el fin de mantener un
 * inventario actualizado en el collection de mongodb.
 *
 * Adicional para el caso de mongo se habilita las operaciones por Repositories de spring data y
 * MongoOperations que es una capa más personalizada para acceder a los datos de mongodb.
 */
@Component
public class BikeRentalCompletingSender {

  private static final Logger log = LoggerFactory.getLogger(BikeRentalCompletingSender.class);

  private final BookingRepository bookingRepository;
  private final BookingDetailsRepository bookingDetailsRepository;
  private final BikeRentalService bikeRentalService;
  private final BikeInventorySender inventorySender;

  /**
   * constructor.
   *
   * @param bookingRepository
   * @param bookingDetailsRepository
   * @param stationRepository
   */
  public BikeRentalCompletingSender(BookingRepository bookingRepository, BookingDetailsRepository bookingDetailsRepository,
      BikeRentalService bikeRentalService, BikeInventorySender inventorySender) {
    this.bookingRepository = bookingRepository;
    this.bookingDetailsRepository = bookingDetailsRepository;
    this.bikeRentalService = bikeRentalService;
    this.inventorySender = inventorySender;
  }

  /**
   * método que permite la actualización del estado del alquiler de las bicicletas a estado
   * completado. luego actualiza el inventario en la collection de mongoDB, incrementando la cantidad
   * de la bicicleta en la estación destino.
   *
   * @param bookingId
   */
  public Mono<Void> completeBikeBooking(int bikeRentId) {
    return completingBikeRental(bikeRentId)
        .flatMap(completingBikeRentalDetails()::apply)
        .flatMap(detail -> inventorySender.updateInventory(detail, InventoryStatus.INCREMENT))
        .then();
  }

  /**
   *
   */
  private Mono<BookingDto> completingBikeRental(int bikeRentId) {
    return bikeRentalService.getBikeRentalByBikeRentId(bikeRentId).flatMap(bikeRental -> {
      bikeRental.setCompletedDate(getSystemDateTime());
      bikeRental.setCompleted(true);
      return Mono.just(bookingRepository.save(bikeRental));
    });
  }

  /**
   *
   */
  private Function<BookingDto, Mono<BookingDetailsDto>> completingBikeRentalDetails() {
    return (bikeRental) -> {
      return Mono
          .fromCallable(
              () -> bookingDetailsRepository.findById(bikeRental.getBookingId()).orElse(new BookingDetailsDto()))
          .flatMap(detail -> {
            detail.setEndDate(bikeRental.getCompletedDate());
            return Mono.fromCallable(() -> bookingDetailsRepository.save(detail));
          });
    };
  }

}
