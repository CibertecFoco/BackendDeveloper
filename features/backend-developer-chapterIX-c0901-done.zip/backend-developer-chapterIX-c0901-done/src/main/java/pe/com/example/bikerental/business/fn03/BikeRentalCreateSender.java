package pe.com.example.bikerental.business.fn03;

import static pe.com.example.bikerental.utils.Utils.getSystemDateTime;
import org.springframework.stereotype.Component;
import pe.com.example.bikerental.business.bikeinventory.BikeInventorySender;
import pe.com.example.bikerental.models.api.fn03.BikeRentResponse;
import pe.com.example.bikerental.models.api.fn03.BookingRequest;
import pe.com.example.bikerental.repository.mssql.BookingDetailsRepository;
import pe.com.example.bikerental.repository.mssql.BookingRepository;
import pe.com.example.bikerental.thirdparty.mongodb.InventoryStatus;
import pe.com.example.bikerental.thirdparty.mssql.BookingDetailsDto;
import pe.com.example.bikerental.thirdparty.mssql.BookingDto;
import reactor.core.publisher.Mono;

@Component
public class BikeRentalCreateSender {

  private final BookingRepository bookingRepository;
  private final BookingDetailsRepository detailsRepository;
  private final BikeInventorySender inventorySender;


  public BikeRentalCreateSender(BookingRepository bookingRepository, BookingDetailsRepository detailsRepository,
      BikeInventorySender inventorySender) {
    this.bookingRepository = bookingRepository;
    this.detailsRepository = detailsRepository;
    this.inventorySender = inventorySender;
  }


/**
   * método que permite realizar los alquieres de las bicicleas, realizando las transacciones en
   * AzureSQL y posteriormente actualizando un inventario en un collection en mongoDB. decrementando
   * la cantidad de la bicicleta en uno a la estación origen del alquiler.
   *
   * Para el caso se almacen tanto el la cabecera y el detalle del alquiler. (AzureSQL)
   *
   * @param payload
   */
public Mono<BikeRentResponse> createBikeBooking(BookingRequest payload) {
    return processBikeRental(payload)
        .flatMap(dtoSaved -> processBikeRentalDetails(dtoSaved, payload))
        .flatMap(detail -> inventorySender.updateInventory(detail, InventoryStatus.DECREMENT))
        .flatMap(res -> Mono.just(new BikeRentResponse(res.getBookingId())));
  }

  /**
   *
   */
  private Mono<BookingDto> processBikeRental(BookingRequest payload) {
    return Mono.defer(() -> {
      BookingDto booking = new BookingDto();
      booking.setBikeId(payload.getBike().getCode());
      booking.setUserId(payload.getUserId());
      booking.setCreateAt(getSystemDateTime());
      return Mono.justOrEmpty(bookingRepository.save(booking));
    });
  }

  /**
   * métooo encardo de parse el payload y bookingId para almacenar el detalle del alquiler.
   * @param dtoSaved
   * @param payload
   * @return
   */
  private Mono<BookingDetailsDto> processBikeRentalDetails(BookingDto dtoSaved, BookingRequest payload) {
    return Mono.defer(() -> {
      BookingDetailsDto details = new BookingDetailsDto();
      details.setBookingId(dtoSaved.getBookingId());
      details.setDestinationStationId(payload.getDestination().getStation().getCode());
      details.setOriginStationId(payload.getOrigin().getStation().getCode());
      details.setStartDate(dtoSaved.getCreateAt());

      return Mono.justOrEmpty(detailsRepository.save(details));

    });
  }

}
