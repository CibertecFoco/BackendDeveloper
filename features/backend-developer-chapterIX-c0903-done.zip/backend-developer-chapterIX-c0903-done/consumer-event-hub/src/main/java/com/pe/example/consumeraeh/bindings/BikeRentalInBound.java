package com.pe.example.consumeraeh.bindings;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

/**
 * Bindable interface with one input channel
 */
public interface BikeRentalInBound {

  String INBOUD = "bikeRentalInbound";

  @Input(BikeRentalInBound.INBOUD)
  SubscribableChannel bikeRentalInbound();

}