package com.pe.example.consumeraeh.models.api.fn03;

public class SourceStationVo {

  private StationVo station;

  /**
   * @return the station
   */
  public StationVo getStation() {
    return station;
  }

  /**
   * @param station the station to set
   */
  public void setStation(StationVo station) {
    this.station = station;
  }
}