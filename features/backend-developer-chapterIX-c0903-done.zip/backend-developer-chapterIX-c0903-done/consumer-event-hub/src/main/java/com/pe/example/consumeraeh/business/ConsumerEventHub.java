package com.pe.example.consumeraeh.business;

import com.pe.example.consumeraeh.bindings.BikeRentalInBound;
import com.pe.example.consumeraeh.models.api.fn03.BookingRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.messaging.Message;

@EnableBinding(BikeRentalInBound.class)
public class ConsumerEventHub {

  private static final Logger log = LoggerFactory.getLogger(ConsumerEventHub.class);

  /**
   * método que realiza el listener para la recepción de datos, que son optenidos desde el Event Hub.
   * Por parametro se recibe un objecto, que por default se deserializa de un formato json.
   * @param payload obejcto recibdo
   */
  @StreamListener(BikeRentalInBound.INBOUD)
  public void handleMessage(BookingRequest payload) {
    log.info("[recieved message] new received : {}", payload);
    // desde aquí puedes procesar la información recibida para procesar y/o persistirla en alguna base
    // de datos o intergrar con otros servicios.
  }

  // Replace destination with spring.cloud.stream.bindings.input.destination
  // Replace group with spring.cloud.stream.bindings.input.group
  @ServiceActivator(inputChannel = "bikerentalinput.$Default.errors")
  public void consumerError(Message<?> message) {
    log.error("Handling customer ERROR: {}", message);
  }

  // Replace destination with spring.cloud.stream.bindings.output.destination
  @ServiceActivator(inputChannel = "bikerentalinput.errors")
  public void producerError(Message<?> message) {
    log.error("Handling Producer ERROR: {}", message);
  }

}
