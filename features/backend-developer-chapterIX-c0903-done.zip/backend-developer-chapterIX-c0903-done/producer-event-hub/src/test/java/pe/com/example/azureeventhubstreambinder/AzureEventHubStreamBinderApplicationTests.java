package pe.com.example.azureeventhubstreambinder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AzureEventHubStreamBinderApplicationTests {

	@Test
	void contextLoads() {
	}

}
