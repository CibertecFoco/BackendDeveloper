package pe.com.example.azureeventhubstreambinder.binding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.stereotype.Component;
import pe.com.example.azureeventhubstreambinder.models.api.fn03.BookingRequest;
import reactor.core.publisher.Mono;

@Component
@EnableBinding(BikeRentalOutput.class)
public class BikeRentalBinding {

  private static final Logger log = LoggerFactory.getLogger(BikeRentalBinding.class);

  private final BikeRentalOutput output;
  // private final Source output;

  public BikeRentalBinding(BikeRentalOutput output) {
  //public BikeRentalBinding(Source output) {
     this.output = output;
  }

  /**
   * método que realiza el envío del payload hacia el event hub en azure.
   *
   * @param payload request que sera enviada a event hub serializada a json
   * @return Mono
   */
  public Mono<?> sendMessageToEventHub(BookingRequest payload) {
    return Mono.defer(() -> {
      Message<?> message = new GenericMessage<>(payload);
      return Mono.fromRunnable(() -> output.bikeRentalOutbound().send(message)).flatMap(data -> Mono.just(payload));
    })
        .doOnSuccess(success -> log.info("[success] send message to Event-Hub."))
        .doOnError(err -> log.error("[error] event hub fail -> {}", err.getMessage()));
  }


}
