package pe.com.example.azureeventhubstreambinder.expose.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import pe.com.example.azureeventhubstreambinder.business.BikeRentalService;
import pe.com.example.azureeventhubstreambinder.models.api.fn03.BookingRequest;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/bike-rental/flux/v1")
public class EventHubController {

  private static final Logger log = LoggerFactory.getLogger(EventHubController.class);

  private final BikeRentalService service;

  public EventHubController(BikeRentalService service) {
    this.service = service;
  }

  @PostMapping("/rents")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public Mono<Void> createBikeRental(@RequestBody BookingRequest payload) {
    log.info("[event hub] start producer message.");
    log.info("payload -> {}", payload);
    return service.producerBikeRental(payload);
  }

}