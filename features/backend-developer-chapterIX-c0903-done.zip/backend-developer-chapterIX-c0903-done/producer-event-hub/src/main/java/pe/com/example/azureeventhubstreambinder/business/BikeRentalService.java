package pe.com.example.azureeventhubstreambinder.business;

import pe.com.example.azureeventhubstreambinder.models.api.fn03.BookingRequest;
import reactor.core.publisher.Mono;

public interface BikeRentalService {

  Mono<Void> producerBikeRental(BookingRequest paylaod);

}