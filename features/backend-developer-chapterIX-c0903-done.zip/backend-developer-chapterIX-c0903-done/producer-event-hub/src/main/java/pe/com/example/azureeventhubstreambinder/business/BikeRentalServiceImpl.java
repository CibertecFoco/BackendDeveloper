package pe.com.example.azureeventhubstreambinder.business;

import org.springframework.stereotype.Service;
import pe.com.example.azureeventhubstreambinder.binding.BikeRentalBinding;
import pe.com.example.azureeventhubstreambinder.models.api.fn03.BookingRequest;
import reactor.core.publisher.Mono;

@Service
public class BikeRentalServiceImpl implements BikeRentalService {

  private final BikeRentalBinding binding;

  public BikeRentalServiceImpl(BikeRentalBinding binding) {
    this.binding = binding;
  }

  @Override
  public Mono<Void> producerBikeRental(BookingRequest paylaod) {
    return binding.sendMessageToEventHub(paylaod)
            .then();
  }


}