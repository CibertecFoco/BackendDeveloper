package pe.com.example.azureeventhubstreambinder.binding;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;

public interface BikeRentalOutput {

  String BIKE_RENTAL_OUTBOUND = "bikeRentalOutbound";

  @Output(BikeRentalOutput.BIKE_RENTAL_OUTBOUND)
  MessageChannel bikeRentalOutbound();

}