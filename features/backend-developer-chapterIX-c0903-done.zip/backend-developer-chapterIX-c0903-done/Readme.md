Azure Event Hub
=========================================================


Casos:
-------

![Azure Event Hub](./eventhubio.svg)

Se realiza dos implementaciones, donde se hará uso de Spring cloud stream para integrase al servicio
de Azure Event Hub.
Consisté en que una aplicación expone un endpoint RESTful, donde se esperá un payload request.
Dicho payload request será enviado a través de un binder de spring cloud stream hacia Event Hubs, para que después, otros aplicaciones y/o servicios se puedan subscribir (aplicaciones consumidoras) a Event Hub y hacer uso de los datos publicados.
Para el caso se envía un payload para la creación de un alquiler de bicicletas y en la aplicación subscriptora se persiste en una base de datos.
Nota. Casó practico se omité la persistencia en la base de datos.

Pasos:
------

- se debe definir las interfaces de entrada y salida cada una en su respectiva aplicación. Revisar las clases
  - BikeRentalInBound.java y BikeRentalOutput.java (Cada una en su aplicación)
- Se debe definir las configuraciones

application producer.
```yml
spring:
  cloud:
    azure:
      eventhub:
        connection-string: <CONNECTION STRINGS> # cambiar la candena de conexión de acuerdo al namespace de event hubs
    stream:
      bindings:
        bikeRentalOutbound: # de la definición de la interface
          destination: biclycleshut # Se define el componente Event Hub
          content-type: 'application/json'
```

application consumer.
```yml
spring:
  cloud:
    azure:
      eventhub:
        connection-string: <CONNECTION STRINGS> # connection string from namespace for envent hub
        checkpoint-storage-account: stacconts # name storage accounts
        checkpoint-access-key: <KEY ACCESS STORAGE ACCOUNTS> # access key from storage account
        bindings:
          bikeRentalInbound: # de la definición de la interface
            consumer:
              start-position: EARLIEST
              # checkpoint-modo: MANUAL
    stream:
      bindings:
        bikeRentalInbound: # de la definición de la interface
          destination: biclycleshut # Defines Event Hub
          group: $Default
          content-type: 'application/json'
```

# Requisitos:

Debe de generarse los componentes en Azure para que el Lab funcioné, revisar los links adjuntos para la creación.

Links:
-------

- https://github.com/microsoft/spring-cloud-azure/tree/release/1.1.0.RC3/spring-cloud-azure-samples
- https://cloud.spring.io/spring-cloud-static/spring-cloud-stream/2.2.1.RELEASE/spring-cloud-stream.html#_destination_bindings
- https://seroter.com/2019/04/03/connecting-your-java-microservices-to-each-other-heres-how-to-use-spring-cloud-stream-with-azure-event-hubs/


