package pe.com.example.factorymethod.pattern;

import static pe.com.example.constants.Constants.TYPE_PERSON_JURIDICA;
import static pe.com.example.constants.Constants.TYPE_PERSON_NATURAL;

public class FactoryMethod {

  public static PersonAbstract createPerson(String type, String personId) {
    if (TYPE_PERSON_NATURAL.equalsIgnoreCase(type)) {
      return new NaturalPerson().loadInformation(personId, type);
    } else if (TYPE_PERSON_JURIDICA.equalsIgnoreCase(type)) {
      return new CorporatePerson().loadInformation(personId, type);
    }
    return null;
  }
}
