package pe.com.example.factorymethod.pattern;

import pe.com.example.AppFactoryMethod;

public abstract class PersonAbstract {

  private String Id;

  private String type;

  /** @return String */
  public String getId() {
    return Id;
  }

  /** @param id String */
  public void setId(String id) {
    Id = id;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public abstract PersonAbstract loadInformation(String type, String personId);
}
