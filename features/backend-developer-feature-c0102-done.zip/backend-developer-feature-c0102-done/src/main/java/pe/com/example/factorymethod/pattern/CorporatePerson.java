package pe.com.example.factorymethod.pattern;

public class CorporatePerson extends PersonAbstract {

  private String legalName;

  private String ruc;

  public String getLegalName() {
    return legalName;
  }

  public void setLegalName(String legalName) {
    this.legalName = legalName;
  }

  public String getRuc() {
    return ruc;
  }

  public void setRuc(String ruc) {
    this.ruc = ruc;
  }

  @Override
  public PersonAbstract loadInformation(String type, String personId) {
    // get some source data
    this.setId(personId);
    this.setType(type);
    this.setRuc("12342564567");
    this.setLegalName("Some legal name");
    return this;
  }

  @Override
  public String toString() {
    return String.format("[%s %s %s %s]", this.getId(), this.getType(), this.getRuc(), this.getLegalName());
  }
}
