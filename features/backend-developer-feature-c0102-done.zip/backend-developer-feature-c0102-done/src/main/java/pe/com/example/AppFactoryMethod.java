package pe.com.example;

import static pe.com.example.constants.Constants.TYPE_PERSON_JURIDICA;
import static pe.com.example.constants.Constants.TYPE_PERSON_NATURAL;
import static pe.com.example.factorymethod.pattern.FactoryMethod.createPerson;

import pe.com.example.factorymethod.pattern.PersonAbstract;
import pe.com.example.factorymethod.pattern.CorporatePerson;
import pe.com.example.factorymethod.pattern.NaturalPerson;

public class AppFactoryMethod {

  public static void main(String[] args) {
    //
    PersonAbstract pj = createPerson(TYPE_PERSON_JURIDICA, "100010106");

    PersonAbstract pn = createPerson(TYPE_PERSON_NATURAL, "101010101");

    if (pj instanceof PersonAbstract) {
      System.out.println("pj es una instancia de de Person Abstract");
    }

    if (pj instanceof CorporatePerson) {
      System.out.println("pj es una instancia de de  PersonaJuridica");
      System.out.println(pj);
    }

    if (pj instanceof NaturalPerson) {
      System.out.println("pj es una instancia de de  PersonaNatural");
    }


    if (pn instanceof PersonAbstract) {
      System.out.println("pn es una instancia de de Person Abstract");
    }

    if (pn instanceof CorporatePerson) {
      System.out.println("pn es una instancia de de PersonaJuridica");
    }

    if (pn instanceof NaturalPerson) {
      System.out.println("pn es una instancia de de PersonaNatural");
      System.out.println(pn);
    }
  }
}
