package pe.com.example.factorymethod.pattern;

import pe.com.example.AppFactoryMethod;

public class NaturalPerson extends PersonAbstract {

  private String name;
  private String born;
  private String gender;

  public String getGender() {
    return gender;
  }

  public void setGender(String gender) {
    this.gender = gender;
  }

  public String getBorn() {
    return born;
  }

  public void setBorn(String born) {
    this.born = born;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  @Override
  public PersonAbstract loadInformation(String type, String personId) {
    // get some source data
    this.setId(personId);
    this.setType(type);
    this.setName("Some name");
    this.setBorn("1990-04-13");
    this.setGender("M");
    return this;
  }

  @Override
  public String toString() {
    return String.format("[%s %s %s %s]", this.getId(), this.getType(), this.getName(), this.getGender());
  }
}
