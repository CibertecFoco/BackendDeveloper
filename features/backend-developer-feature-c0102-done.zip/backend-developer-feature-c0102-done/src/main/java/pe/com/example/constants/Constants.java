package pe.com.example.constants;

public final class Constants {

  public static final String TYPE_PERSON_NATURAL = "N";
  public static final String TYPE_PERSON_JURIDICA = "J";
}
