package pe.com.example.bridge.pattern;

public class AccountProduct extends Product {

  public AccountProduct(Account account) {
    super(account);
  }

  @Override
  public void createProduct() {
    getAccount().debit();

    getAccount().payment();
  }
}
