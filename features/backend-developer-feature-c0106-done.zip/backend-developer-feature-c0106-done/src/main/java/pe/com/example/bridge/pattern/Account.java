package pe.com.example.bridge.pattern;

public interface Account {

  void debit();

  void payment();

}
