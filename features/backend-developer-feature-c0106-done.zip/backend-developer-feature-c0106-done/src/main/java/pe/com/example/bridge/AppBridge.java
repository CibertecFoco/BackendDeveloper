package pe.com.example.bridge;

import pe.com.example.bridge.pattern.Checking;
import pe.com.example.bridge.pattern.AccountProduct;
import pe.com.example.bridge.pattern.Master;
import pe.com.example.bridge.pattern.Savings;

public class AppBridge {

  public static void main(String[] args) {

    // define final implements
    AccountProduct product;

    // set account type Savings
    product = new AccountProduct(new Savings());

    product.createProduct();

    // set account type master
    product = new AccountProduct(new Master());

    product.createProduct();

    // set account type checking
    product = new AccountProduct(new Checking());

    product.createProduct();
  }
}
