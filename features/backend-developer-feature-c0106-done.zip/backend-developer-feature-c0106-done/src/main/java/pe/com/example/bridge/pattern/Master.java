package pe.com.example.bridge.pattern;

public class Master implements Account {
  @Override
  public void debit() {
    System.out.println("debit for account master");
  }

  @Override
  public void payment() {
    System.out.println("payment for account master");
  }
}
