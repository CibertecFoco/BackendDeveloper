package pe.com.example.bridge.pattern;

public abstract class Product {

  private Account account;

  public Product(Account account) {
    this.account = account;
  }

  public Account getAccount() {
    return account;
  }

  public void setAccount(Account account) {
    this.account = account;
  }

  public abstract void createProduct();
}
