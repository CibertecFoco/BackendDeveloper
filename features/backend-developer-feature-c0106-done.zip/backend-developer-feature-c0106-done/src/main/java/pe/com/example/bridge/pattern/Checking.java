package pe.com.example.bridge.pattern;

public class Checking implements Account {
  @Override
  public void debit() {
    System.out.println("debit for account checking");
  }

  @Override
  public void payment() {
    System.out.println("payment for account checking");
  }
}
