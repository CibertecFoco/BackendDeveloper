package pe.com.example.proxy.models;

public class Citizen {

  private String dni;

  private String fullName;

  private String gender;

  private String maritalStatus;

  public String getDni() {
    return dni;
  }

  public void setDni(String dni) {
    this.dni = dni;
  }

  public String getFullName() {
    return fullName;
  }

  public void setFullName(String fullName) {
    this.fullName = fullName;
  }

  public String getGender() {
    return gender;
  }

  public void setGender(String gender) {
    this.gender = gender;
  }

  public String getMaritalStatus() {
    return maritalStatus;
  }

  public void setMaritalStatus(String maritalStatus) {
    this.maritalStatus = maritalStatus;
  }

  @Override
  public String toString() {
    return String.format(
        "Citizen = { dni= %s, fullName=%s, gender=%s, maritalStatus=%s }",
        this.getDni(), this.getFullName(), this.getGender(), this.getMaritalStatus());
  }
}
