package pe.com.example.proxy.pattern;

import java.util.HashMap;
import java.util.Map;
import pe.com.example.proxy.models.Citizen;

public class Cached {

  private static Map<String, Citizen> cache;

  static {
    cache = new HashMap<>();
    Citizen citizen;

    citizen = new Citizen();
    citizen.setDni("12345668");
    citizen.setFullName("Stefeany Ramirez");
    citizen.setGender("F");
    citizen.setMaritalStatus("S");

    cache.put("12345668", citizen);

    citizen = new Citizen();
    citizen.setDni("12345686");
    citizen.setFullName("katherine Ascencio");
    citizen.setGender("F");
    citizen.setMaritalStatus("M");

    cache.put("12345686", citizen);
  }

  public Citizen findCachedByPersonId(String personId) {

    return cache.get(personId);
  }

}
