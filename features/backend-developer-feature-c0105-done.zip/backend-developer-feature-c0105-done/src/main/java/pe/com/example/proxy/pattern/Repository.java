package pe.com.example.proxy.pattern;

import java.util.HashMap;
import java.util.Map;
import pe.com.example.proxy.models.Citizen;

public class Repository {

  private static Map<String, Citizen> db;

  static {
    db = new HashMap<>();
    Citizen citizen;

    citizen = new Citizen();
    citizen.setDni("12345678");
    citizen.setFullName("Eduardo Castillo");
    citizen.setGender("M");
    citizen.setMaritalStatus("S");

    db.put("12345678", citizen);

    citizen = new Citizen();
    citizen.setDni("12345676");
    citizen.setFullName("Marly Manto");
    citizen.setGender("F");
    citizen.setMaritalStatus("S");

    db.put("12345676", citizen);
  }

  public Citizen findDbByPersonId(String personId) {
    return db.get(personId);
  }

}
