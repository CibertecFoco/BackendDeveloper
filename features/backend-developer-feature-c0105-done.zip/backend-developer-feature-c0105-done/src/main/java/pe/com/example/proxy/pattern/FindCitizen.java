package pe.com.example.proxy.pattern;

import pe.com.example.proxy.models.Citizen;

public interface FindCitizen {

  Citizen getInformation(String personId);

}
