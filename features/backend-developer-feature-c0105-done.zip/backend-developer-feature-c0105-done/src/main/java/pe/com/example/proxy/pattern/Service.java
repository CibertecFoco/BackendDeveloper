package pe.com.example.proxy.pattern;

import pe.com.example.proxy.models.Citizen;

public class Service implements FindCitizen {

  private Repository repository;

  public Service() {
    repository = new Repository();
  }

  @Override
  public Citizen getInformation(String personId) {
    return repository.findDbByPersonId(personId);
  }
}
