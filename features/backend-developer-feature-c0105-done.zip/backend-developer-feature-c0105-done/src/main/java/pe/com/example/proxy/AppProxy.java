package pe.com.example.proxy;

import pe.com.example.proxy.pattern.Proxy;
import pe.com.example.proxy.pattern.Service;

public class AppProxy {

  public static void main(String[] args) {
    Proxy proxy = new Proxy();
    // cached 12345686
    System.out.println(proxy.getInformation("12345686"));
    // bd 12345678
    System.out.println(proxy.getInformation("12345678"));
    // cache 12345668
    System.out.println(proxy.getInformation("12345668"));
    // bd 12345676
    System.out.println(proxy.getInformation("12345676"));
  }
}
