package pe.com.example.proxy.pattern;

import pe.com.example.proxy.models.Citizen;

public class Proxy implements FindCitizen {

  private Service service;

  private Cached cached;

  public Proxy() {
    cached = new Cached();
  }

  @Override
    public Citizen getInformation(String personId) {

    Citizen citizen = cached.findCachedByPersonId(personId);
    if (citizen != null) {
      System.out.println("cache");
      return citizen;
    }

    if (service == null) {
      service = new Service();
    }
    System.out.println("db");
    return service.getInformation(personId);
  }
}
