package pe.com.example.api.config;

import javax.servlet.ServletContext;
import javax.servlet.ServletRegistration;
import org.h2.server.web.WebServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

public class MyWebAppInitializer implements WebApplicationInitializer {

  private static final Logger log = LoggerFactory.getLogger(MyWebAppInitializer.class);

  @Override
  public void onStartup(ServletContext container) {
    // Create the 'root' Spring application context
    // AnnotationConfigWebApplicationContext rootContext = new
    // AnnotationConfigWebApplicationContext();
    // rootContext.register(AppConfig.class);

    // Manage the lifecycle of the root application context
    // container.addListener(new ContextLoaderListener(rootContext));

    // Create the dispatcher servlet's Spring application context
    AnnotationConfigWebApplicationContext dispatcherContext =
        new AnnotationConfigWebApplicationContext();
    // dispatcherContext.scan("pe.com.example.expose.web");

    dispatcherContext.register(DispatcherConfig.class);
    dispatcherContext.setServletContext(container);
    // container.addListener(new ContextLoaderListener(dispatcherContext));

    // Register and map the dispatcher servlet
    ServletRegistration.Dynamic dispatcher =
        container.addServlet("dispatcher", new DispatcherServlet(dispatcherContext));
    dispatcher.setLoadOnStartup(1);
    dispatcher.addMapping("/*");

    ServletRegistration.Dynamic h2Distpacher =
        container.addServlet("H2Console", new WebServlet());
    h2Distpacher.setInitParameter("webAllowOthers", "true");
    h2Distpacher.setInitParameter("trace", "true");
    h2Distpacher.setLoadOnStartup(2);
    h2Distpacher.addMapping("/h2-console/*");

    log.debug("[ My Dispacher ] start up");
  }



}
