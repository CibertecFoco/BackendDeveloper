package pe.com.example.bikerental.business.fn06;

import org.springframework.stereotype.Component;
import pe.com.example.bikerental.business.fn05.BikeRentalProcess;
import pe.com.example.bikerental.models.fn05.response.BikeRentalResponse;
import pe.com.example.bikerental.models.fn06.request.ChangeDestinationRequest;

@Component
public class ChangeDestinationProcess {

  private final ChangeDestinationRepository repository;
  private final BikeRentalProcess process;

  public ChangeDestinationProcess(ChangeDestinationRepository repository, BikeRentalProcess process) {
    this.repository = repository;
    this.process = process;
  }

  public BikeRentalResponse changeDestinationBooking(int bookingId,
      ChangeDestinationRequest payload) throws Exception {
    BikeRentalResponse res = null;
    int result = repository.changeDestionationStation(bookingId, payload);
    if (result == 1) {
      res = process.getBikeRental(bookingId);
    } else {
      throw new Exception("don't update destination");
    }
    return res;
  }

}
