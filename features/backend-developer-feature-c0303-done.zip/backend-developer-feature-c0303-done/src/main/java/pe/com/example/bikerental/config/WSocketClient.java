package pe.com.example.bikerental.config;

import java.lang.reflect.Type;
import java.util.Observable;
import java.util.concurrent.TimeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.simp.stomp.StompFrameHandler;
import org.springframework.messaging.simp.stomp.StompHeaders;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;

import pe.com.example.bikerental.thirdparty.websocket.CurrentTime;

@Component
public class WSocketClient extends Observable {

  private static final Logger log = LoggerFactory.getLogger(WSocketClient.class);

  private final ListenableFuture<StompSession> session;

  private final String LISTEN_DESTINATION_ENDPOINT = "/topic/current-time";
  private final String SEND_DESTINATION_ENDPOINT = "/app/current-time";

  public WSocketClient(ListenableFuture<StompSession> session) {
    this.session = session;
  }

  public void onConnectAndRequestDatetime() throws Exception {
    log.info("[Stomp Session] get session server");
    StompSession stSession = session.get(3600, TimeUnit.MILLISECONDS);

    stSession.subscribe(LISTEN_DESTINATION_ENDPOINT, new StompFrameHandler() {

      @Override
      public void handleFrame(StompHeaders headers, Object payload) {
        CurrentTime date = (CurrentTime) payload;

        log.info("Received : " + date.getDateTime() + " from : " + payload);
        setChanged();
        notifyObservers(date);
        //stSession.disconnect();
      }

      @Override
      public Type getPayloadType(StompHeaders headers) {
        return CurrentTime.class;
      }
    });
    log.info("[Stomp Session] subscription done");
    stSession.send(SEND_DESTINATION_ENDPOINT, null);
  }

}
