package pe.com.example.bikerental.business.fn06;

import org.springframework.stereotype.Service;
import pe.com.example.bikerental.models.fn05.response.BikeRentalResponse;
import pe.com.example.bikerental.models.fn06.request.ChangeDestinationRequest;

@Service
public class ChangeDestinationServiceImpl implements ChangeDestinationService {

  private final ChangeDestinationProcess process;

  public ChangeDestinationServiceImpl(ChangeDestinationProcess process) {
    this.process = process;
  }

  @Override
  public BikeRentalResponse changeDestinationBooking(int bookingId,
      ChangeDestinationRequest payload) throws Exception {
    return process.changeDestinationBooking(bookingId, payload);
  }

}