package pe.com.example.api.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public final class JdbcUtil {

  private static final Logger log = LoggerFactory.getLogger(JdbcUtil.class);

  public JdbcUtil() {
    log.info("[jdbc] start connection");
  }

  /**
   * method for open connection to Database and disable auto-commit.
   *
   * @return {@link Connection}
   * @throws SQLException
   */
  public Connection getConnection() throws SQLException {
    log.info("[jdbc] starter get connection ");
    Connection cn =
        DriverManager.getConnection("jdbc:h2:mem:dbTest", "sa", "");
    log.info("[jdbc] connection db!");
    cn.setAutoCommit(false);
    return cn;
  }

  /**
   * method for perform commit sentences
   *
   * @param cn
   */
  public void commit(Connection cn) {
    try {
      if (cn != null) {
        cn.commit();
      }
    } catch (SQLException ex) {
      log.error("[Error Commit] {}", ex.getMessage());
    }
  }

  /**
   * method for perform rollback sentences
   *
   * @param cn
   */
  public void rollback(Connection cn) {
    try {
      if (cn != null) {
        cn.rollback();
      }
    } catch (SQLException ex) {
      log.error(ex.getMessage());
    }
  }
}
