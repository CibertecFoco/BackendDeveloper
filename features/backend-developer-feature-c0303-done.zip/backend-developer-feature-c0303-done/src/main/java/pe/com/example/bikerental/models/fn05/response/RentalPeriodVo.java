package pe.com.example.bikerental.models.fn05.response;

public class RentalPeriodVo {

  private String startRentDate;

  private String endRentDate;


  public String getStartRentDate() {
    return this.startRentDate;
  }

  public void setStartRentDate(String startRentDate) {
    this.startRentDate = startRentDate;
  }

  public String getEndRentDate() {
    return this.endRentDate;
  }

  public void setEndRentDate(String endRentDate) {
    this.endRentDate = endRentDate;
  }


}