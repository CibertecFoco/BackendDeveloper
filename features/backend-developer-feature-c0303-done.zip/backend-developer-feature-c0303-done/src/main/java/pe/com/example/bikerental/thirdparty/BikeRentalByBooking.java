package pe.com.example.bikerental.thirdparty;

public class BikeRentalByBooking {

  private String booking_id;
  private String created_at;
  private String start_date;
  private String end_date;
  private String origin_id;
  private String origin_name;
  private String origin_location;
  private String destination_id;
  private String destination_name;
  private String destination_location;
  private String bike_id;
  private String type;
  private String brand;
  private String price_by_minute;

  public String getBooking_id() {
    return this.booking_id;
  }

  public void setBooking_id(String booking_id) {
    this.booking_id = booking_id;
  }

  public String getCreated_at() {
    return this.created_at;
  }

  public void setCreated_at(String created_at) {
    this.created_at = created_at;
  }

  public String getStart_date() {
    return this.start_date;
  }

  public void setStart_date(String start_date) {
    this.start_date = start_date;
  }

  public String getEnd_date() {
    return this.end_date;
  }

  public void setEnd_date(String end_date) {
    this.end_date = end_date;
  }

  public String getOrigin_id() {
    return this.origin_id;
  }

  public void setOrigin_id(String origin_id) {
    this.origin_id = origin_id;
  }

  public String getOrigin_name() {
    return this.origin_name;
  }

  public void setOrigin_name(String origin_name) {
    this.origin_name = origin_name;
  }

  public String getOrigin_location() {
    return this.origin_location;
  }

  public void setOrigin_location(String origin_location) {
    this.origin_location = origin_location;
  }

  public String getDestination_id() {
    return this.destination_id;
  }

  public void setDestination_id(String destination_id) {
    this.destination_id = destination_id;
  }

  public String getDestination_name() {
    return this.destination_name;
  }

  public void setDestination_name(String destination_name) {
    this.destination_name = destination_name;
  }

  public String getDestination_location() {
    return this.destination_location;
  }

  public void setDestination_location(String destination_location) {
    this.destination_location = destination_location;
  }

  public String getBike_id() {
    return this.bike_id;
  }

  public void setBike_id(String bike_id) {
    this.bike_id = bike_id;
  }

  public String getType() {
    return this.type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getBrand() {
    return this.brand;
  }

  public void setBrand(String brand) {
    this.brand = brand;
  }

  public String getPrice_by_minute() {
    return this.price_by_minute;
  }

  public void setPrice_by_minute(String price_by_minute) {
    this.price_by_minute = price_by_minute;
  }

}