package pe.com.example.bikerental.business.fn06;

import pe.com.example.bikerental.models.fn05.response.BikeRentalResponse;
import pe.com.example.bikerental.models.fn06.request.ChangeDestinationRequest;

public interface ChangeDestinationService {

  BikeRentalResponse changeDestinationBooking(int bookingId, ChangeDestinationRequest payload) throws Exception;

}