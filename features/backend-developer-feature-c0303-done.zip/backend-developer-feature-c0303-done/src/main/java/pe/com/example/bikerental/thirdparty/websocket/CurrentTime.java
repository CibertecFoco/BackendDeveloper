package pe.com.example.bikerental.thirdparty.websocket;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;

/**
 * Class model thridparty for get current datetime from websocket.
 */
public class CurrentTime implements Serializable {

  /**
   *
   */
  private static final long serialVersionUID = 2560213731345308097L;
  @JsonProperty("currentDateTime")
  private String currentDateTime;

  public void setDateTime(String dateTime) {
    this.currentDateTime = dateTime;
  }

  public String getDateTime() {
    return this.currentDateTime;
  }

}
