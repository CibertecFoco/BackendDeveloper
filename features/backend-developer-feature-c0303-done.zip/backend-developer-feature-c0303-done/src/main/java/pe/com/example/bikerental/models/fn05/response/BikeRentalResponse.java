package pe.com.example.bikerental.models.fn05.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class BikeRentalResponse implements Serializable {
  private static final long serialVersionUID = 7242321910301779815L;

  @ApiModelProperty(required = true, value = "identifier booking id")
  private String bookingId;

  @ApiModelProperty(required = true, value = "booking date when registered")
  private String bookingDate;

  @ApiModelProperty(required = true)
  private RentalPeriodVo rentalPeriod;

  @ApiModelProperty(required = true)
  private StationVo stations;

  @ApiModelProperty(required = true)
  private BikeVo bike;

  public RentalPeriodVo getRentalPeriod() {
    return this.rentalPeriod;
  }

  public void setRentalPeriod(RentalPeriodVo rentalPeriod) {
    this.rentalPeriod = rentalPeriod;
  }

  public StationVo getStations() {
    return this.stations;
  }

  public void setStations(StationVo stations) {
    this.stations = stations;
  }

  public BikeVo getBike() {
    return this.bike;
  }

  public void setBike(BikeVo bike) {
    this.bike = bike;
  }

  public String getBookingId() {
    return this.bookingId;
  }

  public void setBookingId(String bookingId) {
    this.bookingId = bookingId;
  }

  public String getBookingDate() {
    return this.bookingDate;
  }

  public void setBookingDate(String bookingDate) {
    this.bookingDate = bookingDate;
  }

}
