package pe.com.example.bikerental.business.fn03;

import java.util.Observable;
import java.util.Observer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pe.com.example.bikerental.thirdparty.websocket.CurrentTime;

public class GetCurrentTime implements Observer {

  private static final Logger log = LoggerFactory.getLogger(GetCurrentTime.class);

  private String datetime;

  @Override
  public void update(Observable o, Object arg) {
    // log.info("[Observador] update");
    this.datetime = ((CurrentTime) arg).getDateTime();
    log.info("[Observador] value: [{}]", datetime);
  }

  public String getWebSocketTime() {
    return this.datetime;
  }


}