package pe.com.example.bikerental.models.fn06.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import javax.validation.Valid;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ChangeDestinationRequest implements Serializable {

  /**
   *
   */
  private static final long serialVersionUID = 8541444566223850302L;
  @ApiModelProperty(value = "Entity destination")
  @Valid

  public Destination getDestination() {
    return this.destination;
  }

  public void setDestination(Destination destination) {
    this.destination = destination;
  }
  private Destination destination;

}
