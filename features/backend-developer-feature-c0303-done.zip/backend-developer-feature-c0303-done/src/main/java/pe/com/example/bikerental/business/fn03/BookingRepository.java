package pe.com.example.bikerental.business.fn03;

import static pe.com.example.bikerental.constants.QueryStatement.QUERY_INSERT_BOOKING;
import static pe.com.example.bikerental.constants.QueryStatement.QUERY_INSERT_RENTAL_DETAILS;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Observer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import pe.com.example.api.database.JdbcUtil;
import pe.com.example.bikerental.config.WSocketClient;
import pe.com.example.bikerental.models.fn03.request.RentalBikeRequest;

@Component
public class BookingRepository {

  private static final Logger log = LoggerFactory.getLogger(BookingRepository.class);

  private final JdbcUtil db;

  private final WSocketClient wsclient;

  public BookingRepository(JdbcUtil db, WSocketClient wsclient) {
    this.db = db;
    this.wsclient = wsclient;
  }

  /**
   * method for create a new booking.
   *
   * @param payload request
   * @throws SQLException exception
   */
  public void createBookingAndDetails(RentalBikeRequest payload) throws Exception {
    String createAt = "";
    GetCurrentTime currentTime = new GetCurrentTime();
    log.info("[start connection ws]");
    wsclient.addObserver(currentTime);
    wsclient.onConnectAndRequestDatetime();
    log.info("[hasChange receive message] {}", currentTime.getWebSocketTime());
    while (currentTime.getWebSocketTime() == null) {
        Thread.sleep(1000);
    }
    wsclient.deleteObserver(currentTime);
    createAt = currentTime.getWebSocketTime();
    log.info("[createAt] websocket server {}", createAt);
    try (Connection cn = db.getConnection()) {
      try (PreparedStatement ps = cn.prepareStatement(QUERY_INSERT_BOOKING)) {
        //String createAt = LocalDateTime.now(ZoneId.of("America/Lima"))
        //    .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'hh:mm:ss"));
        ps.setObject(1, createAt);
        ps.setObject(2, payload.getUserId());
        ps.setObject(3, payload.getBike().getCode());
        int result = ps.executeUpdate();
        db.commit(cn);
        log.info("[create_at] '{}'", createAt);
        log.info("[create booking] result {}", result);
        if (result == 1) {
          try (PreparedStatement psd = cn.prepareStatement(QUERY_INSERT_RENTAL_DETAILS)) {
            psd.setObject(1, createAt);
            psd.setObject(2, payload.getUserId());
            psd.setObject(3, payload.getOrigin().getStation().getCode());
            psd.setObject(4, payload.getDestination().getStation().getCode());
            psd.setObject(5, payload.getStartDate());
            psd.setObject(6, null);
            psd.executeUpdate();
            db.commit(cn);
          }
        }
      }
    }

  }

}
