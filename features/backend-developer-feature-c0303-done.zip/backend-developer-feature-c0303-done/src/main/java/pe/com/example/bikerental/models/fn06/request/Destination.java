package pe.com.example.bikerental.models.fn06.request;

import io.swagger.annotations.ApiModelProperty;
import javax.validation.Valid;

public class Destination {

  @ApiModelProperty(value = "entity station")
  @Valid
  private Station station;

  public Station getStation() {
    return this.station;
  }

  public void setStation(Station station) {
    this.station = station;
  }
}