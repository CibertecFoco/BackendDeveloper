package pe.com.example.bikerental.business.fn05;

import static pe.com.example.bikerental.constants.QueryStatement.QUERY_BIKE_RENTAL_BY_BOOKING;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import pe.com.example.api.database.JdbcUtil;
import pe.com.example.bikerental.thirdparty.BikeRentalByBooking;

@Component
public class BikeRentalRepository {

  private static final Logger log = LoggerFactory.getLogger(BikeRentalRepository.class);

  private final JdbcUtil db;

  public BikeRentalRepository(JdbcUtil db) {
    this.db = db;
  }

  public BikeRentalByBooking getBikeRental(int value) throws SQLException {
    log.info("[start query] get bike rental");
    BikeRentalByBooking bike = null;
    try (Connection cn = db.getConnection()) {
      try (PreparedStatement ps = cn.prepareStatement(QUERY_BIKE_RENTAL_BY_BOOKING)) {
        ps.setInt(1, value);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
          bike = new BikeRentalByBooking();
          bike.setBooking_id(rs.getString("booking_id"));
          bike.setBike_id(rs.getString("bike_id"));
          bike.setType(rs.getString("type"));
          bike.setBrand(rs.getString("brand"));
          bike.setPrice_by_minute(rs.getString("price_by_minute"));
          bike.setCreated_at(rs.getString("created_at"));
          bike.setStart_date(rs.getString("start_date"));
          bike.setEnd_date(rs.getString("end_date"));
          bike.setOrigin_id(rs.getString("origin_id"));
          bike.setOrigin_name(rs.getString("origin_name"));
          bike.setOrigin_location(rs.getString("origin_location"));
          bike.setDestination_id(rs.getString("destination_id"));
          bike.setDestination_name(rs.getString("destination_name"));
          bike.setDestination_location(rs.getString("destination_location"));

        }
      }
    }

    return bike;
  }

}
