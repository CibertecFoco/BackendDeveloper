package pe.com.example.bikerental.expose.web;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.logging.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import pe.com.example.bikerental.business.fn03.BookingService;
import pe.com.example.bikerental.business.fn05.BikeRentalService;
import pe.com.example.bikerental.business.fn06.ChangeDestinationService;
import pe.com.example.bikerental.business.fn07.CancellingBookingService;
import pe.com.example.bikerental.models.fn03.request.RentalBikeRequest;
import pe.com.example.bikerental.models.fn05.response.BikeRentalResponse;
import pe.com.example.bikerental.models.fn06.request.ChangeDestinationRequest;

@Api("Bike Rental - Rental")
@Controller
@RequestMapping(path = "/bike-rental/mvc/v1")
public class WebController {

  private static final Logger log = LoggerFactory.getLogger(WebController.class);

  private final BikeRentalService bikeRentalService;
  private final BookingService bookingService;
  private final ChangeDestinationService changeDestinationService;
  private final CancellingBookingService cancellingBookingService;

  public WebController(@Qualifier("BikeRentalService") BikeRentalService bikeRentalService, BookingService bookingService, ChangeDestinationService changeDestinationService, CancellingBookingService CancellingBookingService) {
    this.bikeRentalService = bikeRentalService;
    this.bookingService = bookingService;
    this.changeDestinationService = changeDestinationService;
    this.cancellingBookingService = CancellingBookingService;
  }

  @ApiOperation(value = "FN03 - Create a new Booking", produces = MediaType.APPLICATION_JSON_VALUE,
      consumes = MediaType.APPLICATION_JSON_VALUE, response = Void.class)
  @PostMapping(value = "/rents", consumes = {MediaType.APPLICATION_JSON_VALUE},
      produces = {MediaType.APPLICATION_JSON_VALUE})
  @ResponseStatus(HttpStatus.CREATED)
  @ResponseBody
  public void createBooking(@RequestBody RentalBikeRequest payload) throws Exception {
    log.info("[create booking] starter");
    bookingService.createNewBooking(payload);
  }

  @ApiOperation(value = "FN05 - Get Rental Bike by bookingId", produces = MediaType.APPLICATION_JSON_VALUE,
      consumes = MediaType.APPLICATION_JSON_VALUE, response = BikeRentalResponse.class)
  @GetMapping(value = "/rents/{bookingId}", consumes = {MediaType.APPLICATION_JSON_VALUE},
      produces = {MediaType.APPLICATION_JSON_VALUE})
  @ResponseStatus(HttpStatus.OK)
  @ResponseBody
  public BikeRentalResponse getBikeRentalByBookingId(@PathVariable("bookingId") int bookingId)
      throws Exception {
    return bikeRentalService.getBikeRental(bookingId);
  }

  @ApiOperation(value = "FN06 - Update destionation station by bookingId",
      produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE,
      response = BikeRentalResponse.class)
  @PatchMapping(value = "/rents/{bookingId}", consumes = {MediaType.APPLICATION_JSON_VALUE},
      produces = {MediaType.APPLICATION_JSON_VALUE})
  @ResponseStatus(HttpStatus.PARTIAL_CONTENT)
  @ResponseBody
  public BikeRentalResponse patchStationDestionation(@PathVariable("bookingId") int bookingId,
      @RequestBody ChangeDestinationRequest payload) throws Exception {
    return changeDestinationService.changeDestinationBooking(bookingId, payload);
  }

  @ApiOperation(value = "FN07 - Cancel Booking Bike by bookingId",
      produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE,
      response = Void.class)
  @DeleteMapping(value = "/rents/{bookingId}", consumes = {MediaType.APPLICATION_JSON_VALUE},
      produces = {MediaType.APPLICATION_JSON_VALUE})
  @ResponseStatus(HttpStatus.NO_CONTENT)
  @ResponseBody
  public void cancelBookingByBookingId(@PathVariable("bookingId") int bookingId) throws Exception {
    cancellingBookingService.cancellingBookingById(bookingId);
  }

}
