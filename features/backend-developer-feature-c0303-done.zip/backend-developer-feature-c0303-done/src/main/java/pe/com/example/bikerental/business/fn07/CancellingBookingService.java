package pe.com.example.bikerental.business.fn07;

import java.sql.SQLException;

public interface CancellingBookingService {

/**
 * method for cancelling booking by bookingId.
 * @param bookingId int
 * @throws SQLException exception
 */
  void cancellingBookingById(int bookingId) throws SQLException;

}