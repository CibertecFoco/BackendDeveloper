package pe.com.example.bikerental.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.converter.MappingJackson2MessageConverter;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.messaging.WebSocketStompClient;
import org.springframework.web.socket.sockjs.client.RestTemplateXhrTransport;
import org.springframework.web.socket.sockjs.client.SockJsClient;
import org.springframework.web.socket.sockjs.client.Transport;
import org.springframework.web.socket.sockjs.client.WebSocketTransport;
import pe.com.example.bikerental.handler.StompSessionHandlerImpl;
import pe.com.example.bikerental.thirdparty.websocket.CurrentTime;

@Configuration
public class WebSocketStompConfig {

  private static final Logger log = LoggerFactory.getLogger(WebSocketStompConfig.class);

  private static final String WEBSOCKET_HOST = "ws://localhost:8082";
  private static final String WEBSOCKET_PATH = "/current-time-websocket";

  @Bean
  public ListenableFuture<StompSession> getConnectionWebSocket() {
    // methods for connection and delivery
    StandardWebSocketClient standardWebSocket = new StandardWebSocketClient();
    WebSocketTransport sockJsTransport = new WebSocketTransport(standardWebSocket);
    RestTemplateXhrTransport xhrTransport = new RestTemplateXhrTransport();
    // add for sockjs manage
    List<Transport> transports = new ArrayList<>();
    transports.add(sockJsTransport);
    transports.add(xhrTransport);
    // define sockJsClient
    SockJsClient sockJsClient = new SockJsClient(transports);
    // WebSocketStompClient stompClient = new WebSocketStompClient(standardWebSocket);
    WebSocketStompClient stompClient = new WebSocketStompClient(sockJsClient);
    // parse messge text to json
    // MappingJackson2MessageConverter converter = new MappingJackson2MessageConverter();
    // ObjectMapper oMapper = new ObjectMapper();
    // oMapper.constructType(CurrentTime.class);
    // converter.setObjectMapper(oMapper);
    stompClient.setMessageConverter(new MappingJackson2MessageConverter());
    log.info("[STOMP CLIENT] starter connection");
    return stompClient.connect(WEBSOCKET_HOST + WEBSOCKET_PATH, new StompSessionHandlerImpl());
  }

}