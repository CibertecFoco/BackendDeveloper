package pe.com.example.bikerental.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.simp.stomp.StompHeaders;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.messaging.simp.stomp.StompSessionHandlerAdapter;

public class StompSessionHandlerImpl extends StompSessionHandlerAdapter {

  private static final Logger log = LoggerFactory.getLogger(StompSessionHandlerImpl.class);

  @Override
  public void handleTransportError(StompSession session, Throwable exception) {
    log.error("[Error Transport] {}", exception.getMessage());
  }

  @Override
  public void afterConnected(StompSession session, StompHeaders connectedHeaders) {
    log.info("[Connection Established WebSocket] {}", session.getSessionId());
  }

}