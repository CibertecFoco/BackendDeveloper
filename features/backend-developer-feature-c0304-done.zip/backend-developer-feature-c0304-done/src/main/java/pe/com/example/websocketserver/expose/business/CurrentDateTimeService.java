package pe.com.example.websocketserver.expose.business;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import pe.com.example.websocketserver.model.CurrentTime;

@Service
public class CurrentDateTimeService {

  private static final Logger log = LoggerFactory.getLogger(CurrentDateTimeService.class);

  /**
   * method that get current time of system.
   * @return CurrentTime
   */
  public CurrentTime getCurrentTime() {
    final String DATE_FORMAT = "yyyy-MM-dd'T'hh:mm:ss";
    final String TIME_ZONE = "America/Lima";
    CurrentTime currentTime = new CurrentTime();
    currentTime.setCurrentDateTime(
        LocalDateTime.now(ZoneId.of(TIME_ZONE)).format(DateTimeFormatter.ofPattern(DATE_FORMAT)));
    log.info("[get datetime] {}", currentTime.getCurrentDateTime());
    return currentTime;
  }

}
