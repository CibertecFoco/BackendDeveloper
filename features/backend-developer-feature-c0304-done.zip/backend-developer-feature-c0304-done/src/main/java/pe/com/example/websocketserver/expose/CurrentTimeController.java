package pe.com.example.websocketserver.expose;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import pe.com.example.websocketserver.expose.business.CurrentDateTimeService;
import pe.com.example.websocketserver.model.CurrentTime;

@Controller
public class CurrentTimeController {

  private static final Logger log = LoggerFactory.getLogger(CurrentTimeController.class);

  private final CurrentDateTimeService service;

  public CurrentTimeController(CurrentDateTimeService service) {
    this.service = service;
  }

  @MessageMapping("/current-time")
  @SendTo("/topic/current-time")
  public CurrentTime getCurrentDateTime() throws Exception {
    log.info("[Request ws]");
    return service.getCurrentTime();
  }

}
