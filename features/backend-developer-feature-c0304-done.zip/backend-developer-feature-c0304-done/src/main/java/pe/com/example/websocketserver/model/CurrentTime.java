package pe.com.example.websocketserver.model;

import java.io.Serializable;

/**
 * Class model for return current date time.
 */
public class CurrentTime implements Serializable {

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  private String currentDateTime;

  public String getCurrentDateTime() {
    return this.currentDateTime;
  }

  public void setCurrentDateTime(String currentDateTime) {
    this.currentDateTime = currentDateTime;
  }

}