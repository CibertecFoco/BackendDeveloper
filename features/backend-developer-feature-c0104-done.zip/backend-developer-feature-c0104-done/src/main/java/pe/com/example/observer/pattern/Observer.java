package pe.com.example.observer.pattern;

public interface Observer {

  void update(Object value);

}
