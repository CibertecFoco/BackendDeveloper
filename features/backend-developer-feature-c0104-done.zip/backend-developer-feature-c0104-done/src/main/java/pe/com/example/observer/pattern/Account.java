package pe.com.example.observer.pattern;

import java.math.BigDecimal;

public class Account extends Observable {

  private BigDecimal balance = BigDecimal.ZERO;

  private String accountId;

  /**
   *
   * @param amount
   */
  public void addAmount(BigDecimal amount) {
    this.balance = this.balance.add(amount);
    setChange(this.balance);
    notifyObservers();
  }

  public String getAccountId() {
    return accountId;
  }

  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }
}
