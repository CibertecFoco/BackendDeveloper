package pe.com.example.observer.pattern;

import java.util.LinkedList;
import java.util.List;

public abstract class Observable {

  private List<Observer> obs;
  private Object change;

  /** Construct an Observable with zero Observers. */
  protected Observable() {
    obs = new LinkedList<>();
  }

  public synchronized void attach(Observer observer) {
    if (observer == null) {
      throw new NullPointerException();
    }
    if (!obs.contains(observer)) {
      obs.add(observer);
    }
  }

  public synchronized void detach(Observer observer) {
    if (observer == null) {
      throw new NullPointerException();
    }
    if (obs.contains(observer)) {
      obs.remove(observer);
    }
  }

  public void notifyObservers() {
    for (Observer observer : this.obs) {
      observer.update(change);
    }
  }

  protected void setChange(Object change) {
    this.change = change;
  }
}
