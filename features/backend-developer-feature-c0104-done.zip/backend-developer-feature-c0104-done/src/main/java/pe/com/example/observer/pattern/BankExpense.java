package pe.com.example.observer.pattern;

import java.math.BigDecimal;

public class BankExpense implements Observer {

  private final BigDecimal rate;
  private String type;
  private BigDecimal total = BigDecimal.ZERO;

  public BankExpense(String type, BigDecimal rate) {
    this.type = type;
    this.rate = rate;
  }

  @Override
  public void update(Object value) {
    this.total = ((BigDecimal) value).multiply(rate);
  }

  public BigDecimal getTotal() {
    return total;
  }

  public String getType() {
    return type;
  }

  @Override
  public String toString() {
    return "BankExpense{"
        + "type= '" + type
        + "', rate= " + rate
        + ", total= " + total
        + '}';
  }
}
