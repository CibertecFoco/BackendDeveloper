package pe.com.example.observer;

import java.math.BigDecimal;
import pe.com.example.observer.pattern.Account;
import pe.com.example.observer.pattern.BankExpense;

public class AppObserver {

  public static void main(String[] args) {
    //
    // Observable class
    Account account = new Account();
    account.setAccountId("1910000000001721");

    // Observer class
    BankExpense bankExpense1 = new BankExpense("commission", BigDecimal.valueOf(0.11d));
    BankExpense bankExpense2 = new BankExpense("expense", BigDecimal.valueOf(0.22d));
    BankExpense bankExpense3 = new BankExpense("compensation", BigDecimal.valueOf(0.33d));

    // Add Observer into Observable
    account.attach(bankExpense1);
    account.attach(bankExpense2);
    account.attach(bankExpense3);

    // Observer initialized notified
    System.out.println(bankExpense1.toString());
    System.out.println(bankExpense2.toString());
    System.out.println(bankExpense3.toString());

    System.out.println("-------------------------------------------------------------------------");

    // Change Observable state
    account.addAmount(BigDecimal.valueOf(1000d));

    // Observer was notified
    System.out.println(bankExpense1.toString());
    System.out.println(bankExpense2.toString());
    System.out.println(bankExpense3.toString());

    System.out.println("-------------------------------------------------------------------------");

    // remove Observer into Observable
    account.detach(bankExpense3 );

    // Change Observable state
    account.addAmount(BigDecimal.valueOf(500d));

    // Observer was notified
    System.out.println(bankExpense1.toString());
    System.out.println(bankExpense2.toString());
    System.out.println(bankExpense3.toString());

  }
}
