package pe.com.example.bikerental.c0801;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C0801ApplicationTests {

	// @Test
	// void contextLoads() {
	// }

}
