

DROP TABLE IF EXISTS DetailStations;
DROP TABLE IF EXISTS rental_details;
DROP TABLE IF EXISTS RentalDetails;
DROP TABLE IF EXISTS Station;
DROP TABLE IF EXISTS Booking;
DROP TABLE IF EXISTS Bike;
DROP TABLE IF EXISTS Userbike;
DROP TABLE IF EXISTS Person;

-- la version de R2dbc 0.8.4 y spring data r2dbc 1.1.2, no cuenta con el soporte para schema dentro de la tabla.
IF NOT EXISTS (SELECT 0 FROM sys.schemas WHERE name = 'CIBERTEC')
 BEGIN
   EXEC ('CREATE SCHEMA CIBERTEC')
 END;

CREATE TABLE Person (
    person_id VARCHAR(5) NOT NULL,
    first_name VARCHAR(60) NOT NULL,
    last_name VARCHAR(40) NOT NULL,
    is_active BIT NOT NULL,
    PRIMARY KEY (person_id)
);

CREATE TABLE Userbike (
    user_id VARCHAR(5) NOT NULL,
    person_id VARCHAR(5) NOT NULL,
    PRIMARY KEY (user_id)
);

CREATE TABLE Booking (
    booking_id int IDENTITY(1,1) NOT NULL,
    is_canceled BIT NOT NULL,
    created_at VARCHAR(60) NOT NULL,
    user_id VARCHAR(5) NOT NULL,
    bike_id VARCHAR(5) NOT NULL,
    is_completed BIT NULL,
    date_completed VARCHAR NULL,
    PRIMARY KEY (booking_id)
);

CREATE TABLE Station (
    station_id VARCHAR(5) NOT NULL,
    name VARCHAR(60) NOT NULL,
    location VARCHAR(50) NOT NULL,
    is_active BIT NOT NULL,
    PRIMARY KEY (station_id)
);

CREATE TABLE Bike (
    bike_id VARCHAR(5) NOT NULL,
    type VARCHAR(30) NOT NULL,
    brand VARCHAR(60) NOT NULL,
    price_by_minute DECIMAL NOT NULL,
    is_active BIT NOT NULL,
    PRIMARY KEY (bike_id)
);

CREATE TABLE rental_details (
    booking_id INT NOT NULL,
    origin_station_id VARCHAR(5) NOT NULL,
    destination_station_id VARCHAR(5) NOT NULL,
    start_date VARCHAR(60) NOT NULL,
    end_date VARCHAR(60)
);

CREATE TABLE DetailStations (
    station_id VARCHAR(5) NOT NULL,
    bike_id VARCHAR(5) NOT NULL,
    quantity INT NOT NULL,
    is_active BIT NOT NULL
);

ALTER TABLE Userbike
  ADD FOREIGN KEY (person_id) REFERENCES Person(person_id);
ALTER TABLE Booking
  ADD FOREIGN KEY (user_id) REFERENCES Userbike(user_id);
ALTER TABLE Booking
  ADD FOREIGN KEY (bike_id) REFERENCES Bike(bike_id);
ALTER TABLE rental_details
  ADD FOREIGN KEY (booking_id) REFERENCES Booking(booking_id);
ALTER TABLE rental_details
  ADD FOREIGN KEY (origin_station_id) REFERENCES Station(station_id);
ALTER TABLE rental_details
  ADD FOREIGN KEY (destination_station_id) REFERENCES Station(station_id);
ALTER TABLE DetailStations
  ADD FOREIGN KEY (station_id) REFERENCES Station(station_id);
ALTER TABLE DetailStations
  ADD FOREIGN KEY (bike_id) REFERENCES Bike(bike_id);

SET IDENTITY_INSERT Booking ON;