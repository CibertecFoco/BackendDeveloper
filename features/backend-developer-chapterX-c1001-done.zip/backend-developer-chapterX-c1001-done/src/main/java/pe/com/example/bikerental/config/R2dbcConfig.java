package pe.com.example.bikerental.config;

import static io.r2dbc.spi.ConnectionFactoryOptions.DATABASE;
import static io.r2dbc.spi.ConnectionFactoryOptions.DRIVER;
import static io.r2dbc.spi.ConnectionFactoryOptions.HOST;
import static io.r2dbc.spi.ConnectionFactoryOptions.PASSWORD;
import static io.r2dbc.spi.ConnectionFactoryOptions.USER;

import io.r2dbc.spi.ConnectionFactories;
import io.r2dbc.spi.ConnectionFactory;
import io.r2dbc.spi.ConnectionFactoryOptions;
import java.nio.charset.Charset;

import io.r2dbc.spi.Option;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.r2dbc.config.AbstractR2dbcConfiguration;
import org.springframework.data.r2dbc.connectionfactory.init.CompositeDatabasePopulator;
import org.springframework.data.r2dbc.connectionfactory.init.ConnectionFactoryInitializer;
import org.springframework.data.r2dbc.connectionfactory.init.ResourceDatabasePopulator;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;
import org.springframework.data.r2dbc.repository.config.EnableR2dbcRepositories;

/**
 * Class: R2dbcConfig.
 *
 * Clase donde se configura la conexión a la base de datos y la carga inicial que esta tendrá.
 *
 */
@Configuration
@EnableR2dbcRepositories(basePackages = "pe.com.example.bikerental.thirdparty")
public class R2dbcConfig extends AbstractR2dbcConfiguration {


  @Autowired
  private MssqlProperties properties;

   @Override
   @Bean
   public ConnectionFactory connectionFactory() {
     ConnectionFactoryOptions options =
         ConnectionFactoryOptions.builder()
             .option(DRIVER, "sqlserver")
             .option(USER, properties.getUsername())
             .option(PASSWORD, properties.getPassword())
             .option(DATABASE, properties.getName())
                   .option(HOST, properties.getUrl())
             .build();
     return ConnectionFactories.get(options);
   }

  /**
   * método que abstrae la inicialización del schema y una carga inicial de datos.
   *
   * @param factory conexión hacia la base de datos
   * @return ConnectionFactoryInitializer
   */
  @Bean
  public ConnectionFactoryInitializer initializerConfig(ConnectionFactory factory) {
    ConnectionFactoryInitializer initializer = new ConnectionFactoryInitializer();
    initializer.setConnectionFactory(factory);

    CompositeDatabasePopulator populator = new CompositeDatabasePopulator();
    ResourceDatabasePopulator resource = new ResourceDatabasePopulator();
    resource.addScript(new ClassPathResource(properties.getSchema()));
    resource.addScript(new ClassPathResource(properties.getData()));
    resource.setContinueOnError(true);
    resource.setIgnoreFailedDrops(true);
    populator.addPopulators(resource);
    initializer.setDatabasePopulator(populator);
    return initializer;
  }


  /**
   * método con el que exponemos en template de spring data para hacer un personalización en las transacciones que se vaya a utilizar.
   * @param factory
   * @return R2dbcEntityTemplate
   */
  @Bean
  public R2dbcEntityTemplate enableEntityTemplate(ConnectionFactory factory) {
    return new R2dbcEntityTemplate(DatabaseClient.create(factory));
  }

}
