package pe.com.example.bikerental.models.fn03;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.io.Serializable;

@JsonInclude(value = Include.NON_NULL)
public class BikeRentResponse implements Serializable {

  /**
   *
   */
  private static final long serialVersionUID = -8692272282241854826L;

  private Integer bikeRentId;

  public BikeRentResponse(Integer bikeRentId) {
    this.bikeRentId = bikeRentId;
  }

  /**
   * @return the bikeRentalId
   */
  public Integer getBikeRentalId() {
    return bikeRentId;
  }

  /**
   * @param bikeRentalId the bikeRentalId to set
   */
  public void setBikeRentalId(Integer bikeRentalId) {
    this.bikeRentId = bikeRentalId;
  }

}