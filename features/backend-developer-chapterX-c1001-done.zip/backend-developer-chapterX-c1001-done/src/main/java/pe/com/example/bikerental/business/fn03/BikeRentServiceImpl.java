package pe.com.example.bikerental.business.fn03;

import org.springframework.stereotype.Service;
import pe.com.example.bikerental.models.fn03.BikeRentRequest;
import pe.com.example.bikerental.models.fn03.BikeRentResponse;
import reactor.core.publisher.Mono;

@Service
public class BikeRentServiceImpl implements BikeRentService {

  private final BikeRentSender sender;

  public BikeRentServiceImpl(BikeRentSender sender) {
    this.sender = sender;
  }

  /**
   * método que se encarga de realizar la llamada a la clase que realizara la transacción en la base
   * de datos.
   */
  @Override
  public Mono<BikeRentResponse> createBikeRental(BikeRentRequest payload) {
    return sender.saveBikeRental(payload);
  }



}
