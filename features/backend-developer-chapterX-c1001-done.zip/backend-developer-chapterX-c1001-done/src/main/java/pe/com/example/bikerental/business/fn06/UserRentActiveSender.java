package pe.com.example.bikerental.business.fn06;

import java.time.Duration;
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;
import org.springframework.stereotype.Component;
import pe.com.example.bikerental.thirdparty.BikeRentalDto;
import reactor.core.publisher.Flux;

/**
 * UserRentActiveSender
 */
@Component
public class UserRentActiveSender {

  private final R2dbcEntityTemplate template;

  public UserRentActiveSender(R2dbcEntityTemplate template) {
    this.template = template;
  }

  public Flux<BikeRentalDto> getUserRentsActivesRents(String userId) {
    return template.select(BikeRentalDto.class)
        .all()
        .delayElements(Duration.ofMillis(2000L));
  }

}
